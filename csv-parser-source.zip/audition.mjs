import {KokoroTTS} from 'kokoro-js';
import {env} from '@huggingface/transformers';
import fs from 'node:fs';
env.cacheDir = './.voice-models';
fs.mkdirSync('auditions', {recursive:true});
const tts = await KokoroTTS.from_pretrained('onnx-community/Kokoro-82M-v1.0-ONNX', {
  dtype:'q8', device:'cpu',
  progress_callback:p=>{if(p.status==='done') console.log('Loaded',p.file)},
});
const lines = [
  "We've reached a quote. Is that the end of the field?",
  "Wait. The chunk stops here. We haven't seen what comes next.",
  "Another quote would mean one quote in the text. A comma would mean the field is finished.",
  "So, keep the text we've built. Keep that question open. Then ask for more bytes.",
];
for(const voice of ['af_heart','af_bella','am_fenrir']){
  for(let i=0;i<lines.length;i++){
    const start=Date.now();
    const audio=await tts.generate(lines[i], {voice,speed: i===1?.94:1.0});
    await audio.save(`auditions/${voice}-${i}.wav`);
    console.log(voice,i,Date.now()-start);
  }
}
fs.writeFileSync('auditions/text.json',JSON.stringify(lines,null,2));
