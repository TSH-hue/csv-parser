from pathlib import Path
import json,re,zipfile,hashlib
ROOT=Path(__file__).resolve().parent
T=json.loads((ROOT/'film-timeline.json').read_text(encoding='utf-8'))
assert not T.get('estimated'), 'Use recorded timings for delivery'
catalog=json.loads((ROOT/'code-catalog.json').read_text(encoding='utf-8'))

def stamp(t):
    n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02}.{n%1000:03}'

chapters=[];parts=[];captions=[]
for scene in T['scenes']:
    if not chapters or chapters[-1]['title']!=scene['chapter']:
        chapters.append(dict(title=scene['chapter'],start=scene['start']))
    for cue in scene['cues']:
        start=scene['start']+cue['start'];end=scene['start']+cue['spoken_end']
        parts.append(dict(scene=scene['id'],title=scene['title'],action=cue['action'],start=start,end=end,text=cue['text'],image=f'review/full/{scene["id"]}-{cue["action"]}.png'))
        # Display the authored words. ASR supplies timing checks, not replacement prose.
        groups=[];group=[]
        for word in cue['words']:
            if group and (len(' '.join(w['text'] for w in group+[word]))>69 or word['end']-group[0]['start']>5.5):groups.append(group);group=[]
            group.append(word)
        if group:groups.append(group)
        for group in groups:
            a=scene['start']+group[0]['start'];b=scene['start']+group[-1]['end']
            captions.append(dict(start=a,end=max(a+.1,b),text=' '.join(w['text'] for w in group)))

(ROOT/'captions.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f'{stamp(c["start"])} --> {stamp(c["end"])} line:86% position:50% size:85% align:center\n{c["text"]}' for c in captions),encoding='utf-8')
(ROOT/'captions.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"]).replace(".",",")} --> {stamp(c["end"]).replace(".",",")}\n{c["text"]}' for i,c in enumerate(captions)),encoding='utf-8')
text=['# When a Comma Is Not a Separator','', 'Complete spoken transcript. Code excerpts are linked to the runnable source.', '']
for scene in T['scenes']:
    text.extend([f'## {stamp(scene["start"])[:-4]} — {scene["title"]}',''])
    text.extend([p['text']+'\n' for p in scene['parts']])
    if scene['id'] in catalog:
        c=catalog[scene['id']];text.extend([f'Code: [{c["path"]}]({c["path"]}), starting at line {c["start"]+1}.','', '```rust',c['code'],'```',''])
(ROOT/'TRANSCRIPT.md').write_text('\n'.join(text),encoding='utf-8')
(ROOT/'chapters.txt').write_text('\n'.join(f'{stamp(c["start"])[:-4]} {c["title"]}' for c in chapters),encoding='utf-8')
files=['rust/lib.rs','rust/import.rs']+[f'checkpoints/{p.name}' for p in sorted((ROOT/'checkpoints').glob('*.rs'))]
data=dict(duration=T['duration'],chapters=chapters,parts=parts,files=files,captions=len(captions))
(ROOT/'player-data.json').write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')

# An actual source package, without local tool caches, model weights or binaries.
paths=[ROOT/p for p in ['Cargo.toml','Cargo.lock','DIALECT.md','TRANSCRIPT.md','VIDEO-NOTES.md','EDITORIAL-REVIEW.md','PROPOSAL.md','PRODUCTION-STATUS.md','DELIVERABLES.md','README.md','vite.config.ts','rustfmt.toml','index.html','full-render.html','render.html','chapters.txt','captions.vtt','captions.srt','prototype-script-narration.wav'] if (ROOT/p).exists()]
for pattern in ['*.py','*.mjs','*.cjs','*.json']:paths.extend(ROOT.glob(pattern))
paths=[p for p in paths if p.name not in {'inspect-scene.cjs','audio-review.json'}]
for d in ['rust','tests','checkpoints','src','review/full']:
    paths.extend(p for p in (ROOT/d).rglob('*') if p.is_file())
with zipfile.ZipFile(ROOT/'csv-parser-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(set(paths)):archive.write(p,str(p.relative_to(ROOT)))
print('Created transcript,',len(captions),'caption groups,',len(chapters),'chapters, and source package')
