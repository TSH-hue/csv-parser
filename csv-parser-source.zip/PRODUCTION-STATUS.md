# CSV film production — complete

Delivered **When a Comma Is Not a Separator**, a standalone **37:29** narrated film at **1920×1080, 30 fps**, with **67,460 frames**. See [the deliverables](DELIVERABLES.md).

## Decisions and final evidence

- Motion Canvas 3.17.2 replaces the prior Pillow scene renderer. Its scene graph, continuous motion, code selection, and deterministic export can preserve individual glyph identity as input becomes fields. Full-HD prototype rendering has succeeded.
- Prototype `renders/prototype-voiced.mp4` covers the doubled quote split between chunks. It is an internal test, not the final film.
- Initial image review found a quote enclosure too short and code crowding the field. Both layouts were revised before expansion. Full scene and exported-movie reviews are complete; further revisions are recorded in EDITORIAL-REVIEW.md.
- Three Kokoro voices were generated with the same four-line passage in `auditions/`. The selected production candidate is `af_heart`, with deliberate utterance breaks and a slower default speed. The first prototype measured about 199 words/minute during speech; full narration uses speed 0.86 to give the screen more time.
- Audio input cannot be heard by the current model interface. No claim of a human listening review is made. ASR, timing and waveform checks cover measured properties. The final voice runs at about 153 words/minute during spoken turns; these checks do not establish universal intuitiveness or a listener's judgment of vocal performance.
- Separate Rust production library: 10 tests pass, including all cuts of every string up to length six over a five-byte CSV alphabet (19,531 strings), selected UTF-8 and CRLF splits, malformed quoting, errors after prior records, short reads, interruptions, and large fields.
- The decoder's real per-byte events are exported to `film-traces.json` for the main execution animations.
- All 32 scenes are authored and voiced: 5,061 words in 224 spoken turns, with a recorded length of 37:28.667. Narration timing is frozen. All 34 code excerpts map to actual source files. Captions contain all authored words in 517 timed groups.
- All 32 scene exports have the exact expected frame count. The combined MP4 decoded in full without errors. All 234 sampled final frames matched reviewed references, including 10 intermediate movement samples. All 224 animation actions fit their recorded timing windows.
- All 224 spoken turns matched the final audio timeline. Minimum waveform correlation: **0.999578**. No cumulative synchronization drift was detected.
- The player passed all 10 chapter seeks, end playback, 517-caption loading, transcript search, source viewing, all 224 study images and mobile overflow checks.
- An extracted source package passed the 10-test Rust suite and TypeScript checking. All seven checkpoint programs and their own tests passed separately.

## Delivery

The full MP4, chaptered player, captions, transcript, source ZIP, exact format policy and review evidence are complete. The ZIP includes the offline lesson files and Rust/animation source. Download the movie separately and place it beside `index.html` for offline use, as described in README.md.

## Preserved originals

`CLAUDE.md` SHA-256: `7820A8ECC210B5EAB0B3921F5104B4BC4506FF91D213896E8F6A8F780272971C`

`tier1_format/02_csv/rust/src/main.rs` SHA-256: `303FD4B3F3486897C9F25417B80BA98A6DD2C08400C0AA4E8631B738BD82780F`

Both files remain unchanged. The production code states its own empty-file policy and does not alter the learner's exercise.
