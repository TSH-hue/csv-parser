# When a Comma Is Not a Separator

A standalone film that builds a streaming CSV reader in Rust: problem, visual decision, code change, execution, and a changed example.

The complete film is **37:29**, at **1920×1080, 30 fps**. Open the local chaptered player at `http://127.0.0.1:8745/`, or play [the MP4](when-a-comma-is-not-a-separator.mp4) directly. There are 10 chapters, 517 caption groups, a searchable transcript, 224 step images and seven runnable Rust checkpoints.

## Keep an offline copy

Download the movie and `csv-parser-source.zip`. Extract the ZIP and place the movie beside `index.html`. Run `python serve.py`, then open `http://127.0.0.1:8745/`. The package includes the 224 step images, chapter data, transcript, captions and Rust source. Serving it locally lets the source viewer and transcript search load their files correctly.

## Run the Rust code

```powershell
cargo run --example import
cargo test
python check_checkpoints.py
```

The library uses only Rust's standard library. The development-only JSON dependency exports execution traces for the animation. See [the exact format policy](DIALECT.md), [the complete reader](rust/lib.rs), and [the tests](tests/streaming.rs).

## Working checkpoints

1. [One field](checkpoints/01_field.rs): accumulate content bytes and form a string.
2. [Plain records](checkpoints/02_records.rs): commas, LF, empty fields, final EOF.
3. [Quoted contents](checkpoints/03_quoted.rs): quoted commas and embedded line breaks. This intentionally incomplete hypothesis does not yet handle escaped or malformed quotes; its limitation test demonstrates the need for the next step.
4. [Complete-input lookahead](checkpoints/04_lookahead.rs): doubled quotes and malformed continuations, with all input available. LF endings only at this stage.
5. [Persistent decoder](checkpoints/05_decoder.rs): keep state and unfinished work across chunks; final source includes CRLF, UTF-8 and structured errors.
6. [Record iterator](checkpoints/06_reader.rs): the blocking `Read` adapter yields complete records.
7. [Application meaning](checkpoints/07_application.rs): headers, field counts, numeric conversion and domain checks.

Every checkpoint has a main program and tests. The last three reference `rust/lib.rs`, included in the source package. To run one separately:

```powershell
rustc --edition 2024 checkpoints/04_lookahead.rs -o checkpoint.exe
./checkpoint.exe
```

The learner's original CSV exercise and `CLAUDE.md` are preserved. These examples use a stated empty-file policy that differs from that exercise.

## Animation sources

The film is authored in Motion Canvas. `src/film.tsx` coordinates the problem-specific actions, and `src/visual.tsx` implements source glyphs, field/record movement and source-linked Rust excerpts. `film.py` contains the spoken turns and editorial intentions. `rust/trace.rs` produces real execution events; `prepare_film.py` imports them using explicit UTF-8.

```powershell
npm install
npm run start
```

The local editor runs at port 9010. Choose `full-project` for the complete animation; `project` is the original internal prototype. The complete project's editor preview is silent. The delivered MP4 contains the narration. The renderer is driven by `render-all.cjs` after all recorded narration timings are frozen.

The source package includes animation source and recorded timing data. Regenerating production audio or running the media review scripts additionally requires Kokoro model weights, FFmpeg, Playwright and the Python media packages. Some helper scripts reference this Windows workstation's tool locations and need those paths adjusted elsewhere. The Rust code and local lesson server do not depend on those production tools.

See [production notes](VIDEO-NOTES.md) for sources and review limits, and [the editorial review](EDITORIAL-REVIEW.md) for the viewer difficulties and revisions addressed in each chapter.
