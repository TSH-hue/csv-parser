# Scope, sources and review notes

This video teaches a specifically defined CSV reader. It does not claim to cover every CSV dialect. Its examples distinguish input delivery boundaries from format boundaries, and CSV structure from application meaning.

## Sources

- [RFC 4180](https://www.rfc-editor.org/rfc/rfc4180.html): the informational memo describing quoted fields, embedded delimiters/line breaks, and doubled quotes.
- [RFC 3629](https://www.rfc-editor.org/rfc/rfc3629.html): UTF-8 byte sequences. ASCII syntax bytes cannot occur as continuation bytes.
- [Rust Read](https://doc.rust-lang.org/std/io/trait.Read.html): byte counts, short reads, zero-byte reads, and read errors.
- [Rust Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html): the item type and `next` result.
- [Motion Canvas](https://motioncanvas.io/docs/): animation authoring and deterministic export.
- [Kokoro](https://github.com/hexgrad/kokoro) and [the ONNX model](https://huggingface.co/onnx-community/Kokoro-82M-v1.0-ONNX): the speech synthesis used for the narration.

## Deliberate choices

- UTF-8, LF and CRLF, no bare CR outside quoted fields, no implicit trimming, no automatic header inference, and no schema validation inside the decoder.
- An empty file has no records. A blank line has one empty field. A trailing comma creates a final empty field. A final record separator creates no phantom record.
- Error offsets are source byte offsets. Invalid UTF-8 errors are anchored at the start of the source field. The film does not portray them as exact character indexes.
- The input adapter is blocking. It treats a zero-byte read as final completion and stops after an error. A nonblocking interface needs a separate waiting contract.
- Streaming avoids collecting the entire file within the reader. It does not bound memory independently of the size of a single record.
- The visuals represent logical values and parser operations, not a literal physical memory layout.

## Production review

The initial prototype exposed code/table overlap and an undersized quote contour; these were corrected. A later review found a Windows subprocess encoding mismatch that corrupted displayed Unicode in trace results; the trace import now explicitly decodes UTF-8. An incomplete UTF-8 prefix is not drawn as a replacement character. Code excerpts are mapped to real source files and shown emerging from their surrounding source context.

Narration is generated as short spoken turns with explicit pauses. The initial test was measured at about 199 words/minute during speech; the production voice was slowed. Three local voice candidates were generated using the same passage. The current model interface cannot hear audio, so no human listening review is claimed. Automated transcription checks pronunciation/coverage flags, and final waveform/visual checks assess measurable synchronization. Those checks do not establish universal intuitiveness or an engaging vocal performance for every viewer.

The completed film is 37:28.667, with 67,460 frames at 1920×1080 and 30 fps. The entire MP4 decoded without errors. All 224 spoken turns were compared with the continuous source narration; the lowest waveform correlation was 0.999578, with no cumulative timing drift detected. All 234 sampled frames matched their reviewed references, including 10 samples during the split, quote merge and code-extraction movements. The largest mean absolute pixel difference was 0.783 on the 0–255 channel scale.

The chaptered player passed all 10 chapter seeks, end playback, 517-caption loading, transcript filtering, source-file selection, 224 step-image checks and mobile overflow checks. All 10 Rust tests also passed from an extracted copy of the source ZIP, and the packaged animation source passed TypeScript checking. The seven checkpoint programs and their tests passed separately.

Evidence: [movie verification](verification.json), [player verification](player-verification.json), [package and caption verification](delivery-verification.json), and [checkpoint results](checkpoint-verification.json). These establish the measured properties above; the listening-review limit still applies.
