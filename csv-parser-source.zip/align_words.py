"""Map authored words onto measured ASR timings, retaining authored captions.
Homophones/acronym tokenization differences are timing gaps, not rewritten text.
"""
from pathlib import Path
import json,re,difflib
ROOT=Path(__file__).resolve().parent

def norm(word):
    word=re.sub('[^a-z0-9]','',word.lower())
    return {'mirror':'mira','t':'tea','high':'hi','bite':'byte','bites':'bytes','bear':'bare','nun':'none','eight':'8','okay':'ok'}.get(word,word)

def align(cue):
    path=ROOT/'audio-review'/(Path(cue['audio']).stem+'.json')
    if not path.exists():raise RuntimeError(f'No timing review for {cue["audio"]}')
    review=json.loads(path.read_text(encoding='utf-8'));heard=review['words'];expected=cue['text'].split()
    match=difflib.SequenceMatcher(None,[norm(w) for w in expected],[norm(w['text']) for w in heard],autojunk=False)
    positions=[None]*len(expected);duration=cue['spoken_end']-cue['start'];trim=cue.get('trim_start',0)
    for block in match.get_matching_blocks():
        for k in range(block.size):
            w=heard[block.b+k]
            a=max(0,min(duration,w['start']-trim));b=max(a,min(duration,w['end']-trim))
            positions[block.a+k]=(a,b)
    i=0
    while i<len(positions):
        if positions[i] is not None:i+=1;continue
        j=i
        while j<len(positions) and positions[j] is None:j+=1
        left=positions[i-1][1] if i else 0
        right=positions[j][0] if j<len(positions) else duration
        right=max(left,right)
        weight=sum(max(1,len(expected[k])) for k in range(i,j));at=left
        for k in range(i,j):
            end=at+(right-left)*max(1,len(expected[k]))/weight;positions[k]=(at,end);at=end
        i=j
    out=[];previous=0
    for word,(a,b) in zip(expected,positions):
        a=max(previous,a);b=max(a,b);previous=a
        out.append(dict(text=word,start=cue['start']+a,end=cue['start']+b))
    return out

def enrich(timeline):
    count=0
    for scene in timeline['scenes']:
        for cue in scene['cues']:
            cue['words']=align(cue);count+=len(cue['words'])
    timeline['wordTimingSource']='authored words aligned to base.en ASR; unmatched words interpolated between matched neighbors'
    return count

if __name__=='__main__':
    path=ROOT/'script-timeline.json';data=json.loads(path.read_text(encoding='utf-8'));count=enrich(data)
    path.write_text(json.dumps(data,indent=2),encoding='utf-8');print('Aligned',count,'authored words')
