"""Check exported pixels, exact frame counts, audio alignment and captions."""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'json-v2/.media-tools'))
sys.path.insert(0, 'C:/Users/fedas/rust/sand/rust-under-glass/.dependencies')
import av
import numpy as np
from PIL import Image
import imageio_ffmpeg

T = json.loads((ROOT / 'film-timeline.json').read_text(encoding='utf-8'))
FF = imageio_ffmpeg.get_ffmpeg_exe()
SOURCES = ['src/film.tsx', 'src/visual.tsx', 'src/full-render.ts',
           'film-timeline.json', 'film-traces.json', 'code-catalog.json']
SIGNATURE = hashlib.sha256(b''.join((ROOT / p).read_bytes() for p in SOURCES)).hexdigest()


def video_info(path, expected):
    with av.open(str(path)) as c:
        v = c.streams.video[0]
        info = dict(width=v.width, height=v.height, fps=float(v.average_rate),
                    frames=v.frames, duration=float(v.duration * v.time_base))
    assert (info['width'], info['height']) == (1920, 1080), info
    assert info['fps'] == 30, info
    assert info['frames'] == round(expected * 30), (path.name, info, expected)
    assert abs(info['duration'] - expected) < .001, (path.name, info, expected)
    return info


def picture_checks(path, scenes, global_time=False):
    checks = []
    with av.open(str(path)) as container:
        stream = container.streams.video[0]
        stream.thread_type = 'AUTO'
        stream.codec_context.thread_count = 6
        for scene in scenes:
            offset = scene['start'] if global_time else 0
            targets = [dict(action=c['action'], local=min(scene['duration']-.2, c['spoken_end']-.25),
                            file=f'review/full/{scene["id"]}-{c["action"]}.png') for c in scene['cues']]
            motion_path = ROOT/'review/motion-checks.json'
            if motion_path.exists():
                targets.extend(c for c in json.loads(motion_path.read_text()) if c['scene']==scene['id'])
            for cue in targets:
                local = cue['local']
                # renderFrame uses ceil(time*30), matching the browser reference.
                frame_number = int(np.ceil(local * 30)) + round(offset * 30)
                sec = frame_number / 30
                container.seek(max(0, int((sec - .08) / float(stream.time_base))),
                               stream=stream, backward=True, any_frame=False)
                decoded = None
                for frame in container.decode(stream):
                    number = round(float(frame.pts * stream.time_base) * 30)
                    if number >= frame_number:
                        assert number == frame_number, (scene['id'], number, frame_number)
                        decoded = frame.to_image()
                        break
                assert decoded is not None, (scene['id'], cue['action'])
                reference = Image.open(ROOT / cue['file'])
                a = np.asarray(decoded.resize((960, 540)), dtype=np.int16)
                b = np.asarray(reference.convert('RGB').resize((960, 540)), dtype=np.int16)
                diff = np.abs(a - b)
                mae = float(diff.mean())
                large = float((diff.max(axis=2) > 45).mean())
                row = dict(scene=scene['id'], action=cue['action'], time=sec,
                           mae=mae, large_difference_fraction=large)
                checks.append(row)
                assert mae < 4 and large < .028, row
            print('Exported pixels verified:', scene['id'], flush=True)
    return checks


def clips():
    results = []
    for s in T['scenes']:
        p = ROOT / 'renders' / f'{s["id"]}.mp4'
        meta = p.with_suffix('.json')
        if not meta.exists() or json.loads(meta.read_text())['signature'] != SIGNATURE:
            continue
        info = video_info(p, s['duration'])
        sha = hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
        check_path = ROOT / 'review' / f'{s["id"]}-export.json'
        if check_path.exists():
            cached = json.loads(check_path.read_text())
            motion_path = ROOT/'review/motion-checks.json'
            extra_count = sum(c['scene']==s['id'] for c in json.loads(motion_path.read_text())) if motion_path.exists() else 0
            if cached.get('sha256') == sha and len(cached.get('images',[]))==7+extra_count:
                results.append(cached)
                continue
        record = dict(scene=s['id'], **info, sha256=sha,
                      images=picture_checks(p, [s]))
        check_path.write_text(json.dumps(record, indent=2))
        results.append(record)
    print(f'{len(results)}/32 current scene exports verified.', flush=True)
    return results


def pcm(path):
    return np.frombuffer(subprocess.check_output([
        FF, '-v', 'error', '-i', str(path), '-vn', '-f', 'f32le',
        '-ac', '1', '-ar', '16000', '-']), np.float32)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--clips', action='store_true')
    args = parser.parse_args()
    clip_results = clips()
    if args.clips:
        return
    assert len(clip_results) == len(T['scenes'])
    movie = ROOT / 'when-a-comma-is-not-a-separator.mp4'
    info = video_info(movie, T['duration'])
    expected_chapters = []
    for scene in T['scenes']:
        if not expected_chapters or expected_chapters[-1]['title'] != scene['chapter']:
            expected_chapters.append(dict(start=scene['start'], title=scene['chapter']))
    with av.open(str(movie)) as c:
        chapters = c.chapters()
        assert len(chapters) == len(expected_chapters) == 10
        for actual, expected in zip(chapters, expected_chapters):
            assert abs(float(actual['start'] * actual['time_base']) - expected['start']) < .001
            assert actual['metadata']['title'] == expected['title']
        assert c.streams.audio[0].codec_context.name == 'aac'
        assert len(c.streams.subtitles) == 1
    decode = subprocess.run([FF, '-v', 'error', '-i', str(movie), '-f', 'null', '-'],
                            capture_output=True, text=True, check=True)
    assert not decode.stderr.strip(), decode.stderr
    print('Entire movie decoded without errors.', flush=True)
    expected, actual = pcm(ROOT / 'script-narration.wav'), pcm(movie)
    assert abs(len(expected) - len(actual)) < 2000
    comparisons = []
    for scene in T['scenes']:
        for cue in scene['cues']:
            a = round((scene['start'] + cue['start']) * 16000)
            b = round((scene['start'] + cue['spoken_end']) * 16000)
            x, y = expected[a:b].astype(np.float64), actual[a:b].astype(np.float64)
            corr = float(np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y)))
            assert corr > .975, (scene['id'], cue['action'], corr)
            comparisons.append(dict(scene=scene['id'], action=cue['action'], correlation=corr))
    del actual, expected
    print('All 224 spoken turns match the final audio timeline.', flush=True)
    pictures = picture_checks(movie, T['scenes'], global_time=True)
    report = dict(**info, chapters=10, full_decode='passed',
                  scene_exports=clip_results, spoken_turn_audio_checks=comparisons,
                  movie_frame_checks=pictures,
                  video_sha256=hashlib.file_digest(movie.open('rb'), 'sha256').hexdigest())
    (ROOT / 'verification.json').write_text(json.dumps(report, indent=2))
    print('Full movie verification passed.', flush=True)


if __name__ == '__main__':
    main()
