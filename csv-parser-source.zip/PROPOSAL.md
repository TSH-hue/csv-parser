# Video 2 proposal: When a Comma Is Not a Separator

Status: the full 37:29 film is built. The original planning estimate below was extended to preserve the recorded pacing. See README.md for the movie and study materials, and PRODUCTION-STATUS.md for verification evidence.

## Viewer outcome

Build a Rust CSV reader that preserves field contents and record boundaries, handles quoted commas, embedded line breaks and doubled quotes, and yields complete records when input arrives in arbitrary chunks. Understand how the required memory becomes parser state, how state becomes a Rust enum, and why the input source, CSV rules and application rules have separate responsibilities.

Target: about 33 minutes, with a 30–35 minute planning range. The scene timing must be established by a spoken animatic, not by accelerating explanations to meet a number. The episode is standalone.

## Reflection on the JSON film

The introduction described the undertaking before establishing a sharp discrepancy between an obvious first attempt and the required output. The renderer also made generic lists and arrows too convenient, even when manipulating the actual data would have explained more. Consistently paced paragraph narration left too little space for noticing, predicting, and reconsidering. Production checks were more concrete than the editorial criteria for engagement and transfer.

These are production choices to change, not shortcomings to disguise with new colors or random conversational filler.

## The opening

Show `Mira,"bread, milk"` as an import into a two-column table. Briefly establish that CSV is text used to represent records and fields. Show the required result: `Mira` and `bread, milk`.

Try splitting at every comma. Keep the three resulting pieces connected to their exact source positions, so the broken second field is visible. Ask why the comma after Mira separates fields while the comma after bread belongs in the field. Let the viewer inspect the quotation marks before outlining the promise of the episode.

Do not pile streaming, doubled quotes, UTF-8 and malformed input into the opening. Each will become a new problem after the previous agreement works.

## Start-to-finish sequence

Every section repeats a short cycle: concrete case, expected output, visual decision, corresponding Rust change, execution of the same case, and one variation. This is not a visual lecture followed by a separate code translation.

| Approximate time | New problem and likely struggle | Visual resolution and construction |
|---|---|---|
| 0–2 min | What are we building, and why does splitting fail? | Animate the opening import, the three incorrect pieces, and the two intended fields. State the useful end result. |
| 2–6 min | Where do field text, a finished field, and a finished record go? | Start with one field, then add a comma and a second record. Text accumulates in one active cell; finishing a field places that cell in the current record. Finishing the record delivers it. Introduce the small Rust buffers and operations at those exact moments. Empty and trailing fields are shown when the first boundary decisions arise. |
| 6–11 min | Why is the same comma or line break sometimes ordinary data? | Opening quotes create a visible enclosure for one field. An internal comma travels into that field's contents. An embedded line break expands the cell onto another line while the record remains unfinished. Compare identical characters inside and outside the enclosure, then execute the relevant Rust branch. |
| 11–16 min | Does a quote end the field or represent a quote character? | Add doubled quotes. Briefly keep two possible interpretations visible at the first quote. The next byte resolves the choice; two source quotes contribute one output quote. Build the necessary check and show an invalid character after a closing quote as a counterexample. |
| 16–23 min | What if the next byte has not arrived in the current chunk? | Cut the same input between the two quotes. The completed prefix and unfinished field stay visible while the next chunk arrives. Derive the need to remember the pending decision, then name the states in a Rust enum. Distinguish a chunk boundary from final EOF. Show the same issue with CR/LF and a multibyte UTF-8 character, without treating individual UTF-8 bytes as characters. |
| 23–29 min | How does an application get one complete record without collecting the entire file? | A consumer asks for the next record; the reader consumes enough input, hands over that record, and retains unfinished work and unread input. Connect this to the iterator's item/end/error outcomes. File I/O supplies bytes; CSV determines field and record boundaries; the application interprets headers, field counts and values. Make these responsibilities visible before naming the Rust interfaces. |
| 29–33 min | Can the viewer reuse the decisions on unfamiliar input? | Recombine empty fields, doubled quotes, an embedded newline and awkward chunk boundaries in a fresh example. Give a short prediction pause, then show the complete result. Move the chunk boundaries without changing the bytes and show that the records remain identical. End with a brief contrast to message framing: an input chunk need not be a logical message. Explain the shared principle and the different format rules. |

## Visual language for this problem

Keep the source and emerging table as the main objects. Use a contour around the currently quoted field, a visibly unfinished cell, and exact paths from consumed source spans to their output contents. Labels accompany color so an inside/outside distinction does not rely on color alone.

Streaming introduces boundaries drawn over the same source text; it does not replace the source with an unrelated conveyor-belt metaphor. A chunk can end inside a field or even between bytes of one character. The field and record builders remain in place across that event. Completed records leave the working area when the consumer receives them.

Rust excerpts come from the growing whole file, enlarge beside the corresponding visual operation, and return to their original location. Highlight the decision and the change it causes. Show ownership transfer when handing over a field or record; do not depict logical diagrams as physical memory layouts.

## Narration and performance

Opening sample:

> We want two cells here: Mira, and bread, milk. Let's split at the commas. [The three pieces separate.] Wait—we've made three cells. [Pause on the comma inside the quotes.] This comma belongs in the note. So what tells us to keep it? The quotes around this field.

Streaming sample:

> We've reached a quote. Is that the end of the field? [Pause before revealing the next chunk.] We can't decide from this chunk alone. Another quote would mean one quote in the text. A comma would mean the field is finished. So we need to keep this decision open until the next byte arrives.

Use selective repetition at these actual decision points. Allow silent motion to finish. Perform short voice auditions using the same passage and compare attentiveness, emphasis and pace changes. Adding “uh” indiscriminately is not the performance plan; an occasional hesitation is useful when it gives the viewer space to inspect a real ambiguity.

## Generalization and editorial review

After each successful case, change one thing and show the consequence: comma inside versus outside quotes; two quotes in one chunk versus split across chunks; end of a chunk versus final EOF; one completed record versus the next record still incomplete.

The general principles must be earned locally: retain only the context needed to interpret the next byte; distinguish physical input boundaries from logical data boundaries; produce a result only when its completion condition is met; keep source access and application meaning outside CSV recognition.

Prototype the hardest minute—the doubled quote split between chunks—before committing to the full visual system and narration. Review every chapter for unresolved questions, unnecessary repetition, unexplained syntax, visual referents, and whether its variation actually demonstrates transfer. A failed editorial check calls for a rewrite, not another render at higher resolution.

## Technical scope and evidence planned

- Base quoting, embedded line breaks and doubled quotes on the format documented in RFC 4180. Explicitly identify chosen UTF-8, LF/CRLF, empty-input and malformed-input policies; do not claim to support every CSV dialect.
- Proposed empty-input policy: no records. A blank record has one empty field; a final delimiter creates a final empty field; a terminal record separator does not manufacture an additional record. These are production choices to explain, not silent changes to the learner's existing tests.
- Demonstrate that splitting a test input at every possible two-chunk boundary, or feeding it one byte at a time, preserves output and error positions.
- Include malformed quoting, real EOF during a quoted field, trailing fields, CRLF split between chunks, UTF-8 split between bytes, and I/O errors.
- State the memory claim precisely: the adapter and unfinished record need storage; yielding records avoids collecting the entire file, but a single enormous record can still require substantial memory.
- Provide independently runnable checkpoints, captions, a transcript, and source/lesson links. Keep all production code separate from the learner's source and CLAUDE.md.

References: [RFC 4180](https://www.rfc-editor.org/rfc/rfc4180.html), [Rust Read](https://doc.rust-lang.org/std/io/trait.Read.html), [Rust Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html).
