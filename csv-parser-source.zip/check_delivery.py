"""Verify the captions, linked source excerpts and downloadable package."""
from pathlib import Path
import hashlib, json, re, zipfile, textwrap

ROOT = Path(__file__).resolve().parent
T = json.loads((ROOT/'film-timeline.json').read_text(encoding='utf-8'))
data = json.loads((ROOT/'player-data.json').read_text(encoding='utf-8'))
assert not T.get('estimated')
assert len(data['parts']) == 224 and len(data['chapters']) == 10
assert abs(T['duration'] - data['duration']) < 1e-6
for part in data['parts']:
    assert 0 <= part['start'] < part['end'] <= T['duration']
    assert (ROOT/part['image']).is_file(), part['image']
catalog = json.loads((ROOT/'code-catalog.json').read_text(encoding='utf-8'))
for name, c in catalog.items():
    full = (ROOT/c['path']).read_text(encoding='utf-8')
    assert c['full'] == full, name
    assert c['code'] == textwrap.dedent('\n'.join(full.splitlines()[c['start']:c['end']])), name

def stamp(value):
    h,m,s = value.replace(',', '.').split(':')
    return int(h)*3600 + int(m)*60 + float(s)

vtt = (ROOT/'captions.vtt').read_text(encoding='utf-8')
srt = (ROOT/'captions.srt').read_text(encoding='utf-8')
pattern = r'(\d\d:\d\d:\d\d[.,]\d{3}) --> (\d\d:\d\d:\d\d[.,]\d{3})[^\n]*\n([^\n]+)'
captions = [(stamp(a),stamp(b),text) for a,b,text in re.findall(pattern,vtt)]
srt_captions = [(stamp(a),stamp(b),text) for a,b,text in re.findall(pattern,srt)]
assert captions == srt_captions and len(captions) == data['captions']
last = 0
for a,b,text in captions:
    assert 0 <= a < b <= T['duration']+.001, (a,b,text)
    assert a >= last-.001, (last,a,text)
    assert len(text) <= 69
    last = b
spoken = ' '.join(c['text'] for scene in T['scenes'] for c in scene['cues'])
assert ' '.join(text for _,_,text in captions).split() == spoken.split()
with zipfile.ZipFile(ROOT/'csv-parser-source.zip') as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names))
    for p in data['files'] + ['Cargo.toml','tests/streaming.rs']:
        assert archive.read(p) == (ROOT/p).read_bytes(), p
    assert not any('node_modules/' in n or n.endswith('.exe') for n in names)
originals = {
    ROOT.parents[1]/'CLAUDE.md': '7820A8ECC210B5EAB0B3921F5104B4BC4506FF91D213896E8F6A8F780272971C',
    ROOT.parents[1]/'tier1_format/02_csv/rust/src/main.rs': '303FD4B3F3486897C9F25417B80BA98A6DD2C08400C0AA4E8631B738BD82780F',
}
for path, expected in originals.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest().upper() == expected, str(path)
report = dict(caption_groups=len(captions), authored_word_coverage='exact',
              caption_timing='ordered and non-overlapping', source_excerpts=len(catalog),
              step_images=len(data['parts']), chapters=len(data['chapters']),
              source_package_files=len(names), original_files='unchanged')
(ROOT/'delivery-verification.json').write_text(json.dumps(report,indent=2))
print('Captions, source excerpts, package integrity and preserved originals passed.')
