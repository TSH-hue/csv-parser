from pathlib import Path
import json, sys, wave, math, subprocess
import numpy as np
sys.path.insert(0,'C:/Users/fedas/rust/sand/rust-under-glass/.dependencies')
import imageio_ffmpeg

ROOT=Path(__file__).resolve().parent
file=Path(sys.argv[1] if len(sys.argv)>1 else 'script-voiced.json')
scenes=json.loads(file.read_text(encoding='utf-8'))
assert all(p.get('audio') and (ROOT/p['audio']).exists() for s in scenes for p in s['parts'] if p.get('text')), 'Narration is not complete yet'
stem=file.name.replace('-voiced.json','')
sr=24000
timeline=[]; total=0
(ROOT/'audio-scenes').mkdir(exist_ok=True)
with wave.open(str(ROOT/f'{stem}-narration.wav'),'wb') as out:
    out.setnchannels(1);out.setsampwidth(2);out.setframerate(sr)
    for scene in scenes:
        start=total; cursor=0; pieces=[]; cues=[]
        def silence(seconds):
            global cursor
            n=round(seconds*sr);pieces.append(np.zeros(n,dtype=np.float32));cursor+=n
        silence(0.65)
        for part in scene['parts']:
            p=dict(part);p['start']=cursor/sr
            if part.get('audio'):
                raw=subprocess.check_output([imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-i',str(ROOT/part['audio']),'-f','f32le','-ar',str(sr),'-ac','1','-'])
                a=np.frombuffer(raw,dtype='<f4').copy()
                # Trim only edge silence; retain the model's internal phrasing.
                active=np.where(np.abs(a)>.004)[0]
                trim_start=max(0,active[0]-round(.07*sr)) if len(active) else 0
                trim_end=min(len(a),active[-1]+round(.15*sr)) if len(active) else len(a)
                a=a[trim_start:trim_end];p['trim_start']=trim_start/sr
                a*=min(.13/max(float(np.sqrt(np.mean(a*a))),1e-6),.9/max(float(np.abs(a).max()),1e-6))
                pieces.append(a);cursor+=len(a)
            p['spoken_end']=cursor/sr
            silence(part.get('pause',.65));p['end']=cursor/sr;cues.append(p)
        n=math.ceil(cursor/(sr/30))*int(sr/30)-cursor
        if n:pieces.append(np.zeros(n,dtype=np.float32));cursor+=n
        audio=np.concatenate(pieces)
        out.writeframes((np.clip(audio,-1,1)*32767).astype('<i2').tobytes())
        with wave.open(str(ROOT/'audio-scenes'/f'{scene["id"]}.wav'),'wb') as clip:
            clip.setnchannels(1);clip.setsampwidth(2);clip.setframerate(sr)
            clip.writeframes((np.clip(audio,-1,1)*32767).astype('<i2').tobytes())
        duration=cursor/sr
        scene=dict(scene,start=total,duration=duration,cues=cues)
        timeline.append(scene);total+=duration
result={'fps':30,'voice':'Kokoro af_heart q8','duration':total,'scenes':timeline}
(ROOT/f'{stem}-timeline.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(f'{stem}: {total:.2f}s / {total/60:.2f}min, {sum(len(s["cues"]) for s in timeline)} utterances')
