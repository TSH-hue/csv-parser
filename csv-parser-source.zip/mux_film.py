from pathlib import Path
import json,sys,subprocess,hashlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'C:/Users/fedas/rust/sand/rust-under-glass/.dependencies')
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()
T=json.loads((ROOT/'film-timeline.json').read_text(encoding='utf-8'))
assert not T.get('estimated')
frames=round(T['duration']*30)
concat=['ffconcat version 1.0']
for s in T['scenes']:
    p=ROOT/'renders'/f'{s["id"]}.mp4'
    assert p.exists() and p.with_suffix('.json').exists(),p
    concat.extend([f"file '{p.as_posix()}'",f'duration {s["duration"]:.9f}'])
(ROOT/'movie.ffconcat').write_text('\n'.join(concat),encoding='utf-8')
chapters=[]
for s in T['scenes']:
    if not chapters or chapters[-1]['title']!=s['chapter']:chapters.append(dict(title=s['chapter'],start=s['start']))
meta=[';FFMETADATA1','title=When a Comma Is Not a Separator','comment=Build a streaming CSV reader in Rust. Sources and format policy accompany the film.']
for i,c in enumerate(chapters):
    end=chapters[i+1]['start'] if i+1<len(chapters) else T['duration']
    meta.extend(['[CHAPTER]','TIMEBASE=1/1000',f'START={round(c["start"]*1000)}',f'END={round(end*1000)}',f'title={c["title"]}'])
(ROOT/'chapters.ffmeta').write_text('\n'.join(meta),encoding='utf-8')
out=ROOT/'when-a-comma-is-not-a-separator.mp4'
args=[FF,'-y','-v','warning','-stats','-f','concat','-safe','0','-i',str(ROOT/'movie.ffconcat'),'-i',str(ROOT/'script-narration.wav'),'-i',str(ROOT/'captions.srt'),'-f','ffmetadata','-i',str(ROOT/'chapters.ffmeta'),'-map','0:v:0','-map','1:a:0','-map','2:s:0','-map_metadata','3','-map_chapters','3','-c:v','copy','-c:a','aac','-b:a','128k','-c:s','mov_text','-metadata:s:s:0','language=eng','-metadata:s:s:0','title=English','-t',f'{T["duration"]:.9f}','-movflags','+faststart',str(out)]
subprocess.run(args,check=True)
print('Muxed',out.name,'SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
