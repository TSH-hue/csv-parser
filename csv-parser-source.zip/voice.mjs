import {KokoroTTS} from 'kokoro-js';
import {env} from '@huggingface/transformers';
import fs from 'node:fs';
import crypto from 'node:crypto';
env.cacheDir='./.voice-models';
const input=process.argv[2]||'script.json';
const scenes=JSON.parse(fs.readFileSync(input,'utf8'));
fs.mkdirSync('audio',{recursive:true});
const voice='af_heart';
const tts=await KokoroTTS.from_pretrained('onnx-community/Kokoro-82M-v1.0-ONNX',{dtype:'q8',device:'cpu'});
for(const scene of scenes){
 for(let i=0;i<scene.parts.length;i++){
  const part=scene.parts[i];
  if(!part.text) continue;
  const speed=part.speed||0.86;
  const hash=crypto.createHash('sha256').update(voice+speed+part.text).digest('hex').slice(0,12);
  part.audio=`audio/${scene.id}-${i}-${hash}.wav`;
  if(fs.existsSync(part.audio))continue;
  const started=Date.now();
  const audio=await tts.generate(part.text,{voice,speed});
  await audio.save(part.audio);
  console.log(scene.id,i,Math.round((Date.now()-started)/1000)+'s');
 }
 fs.writeFileSync(input.replace('.json','-voiced.json'),JSON.stringify(scenes,null,2));
}
