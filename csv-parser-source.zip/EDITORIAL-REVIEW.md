# Editorial review: When a Comma Is Not a Separator

The film's outcome is to build a CSV reader whose answers survive awkward input delivery, and to understand why the source, decoder, and application have separate jobs. The animation follows source text into field contents and completed records. Rust appears when the visible decision needs an implementation.

## Chapter-by-chapter questions

| Chapter | Where a viewer may struggle | How the film addresses it | Changed case that checks the idea |
|---|---|---|---|
| The useful result | Why is this more than splitting a string? What are fields and records? | Begin with the desired two cells. Make the naive split produce three pieces at the spoken counts. Define the terms using those cells. | Compare the two identical comma characters and their different jobs. |
| From bytes to records | Where does unfinished text go? What exactly becomes complete? | Keep an active field, finished fields, and a delivered record distinct. Move the values when their completion condition occurs. Introduce `Vec`, `push`, `mem::take`, conversion and `?` through their effects. | New names, a second record, leading/trailing emptiness, blank line versus empty input. |
| The punctuation changes jobs | Why is a newline sometimes content? Where may quoting begin? | Preserve the same source and field. A quote contour changes how the next punctuation is interpreted; a quoted line break expands the cell vertically. | Remove surrounding quotes; put a quote after bare content or a leading space. |
| A quote inside the value | Which of several adjacent quotes belongs in the answer? | Follow the first quote to the next byte, merge two source marks into one content quote, then distinguish the final closing mark. | Quote followed by quote, separator, final EOF, or invalid text. |
| Remember exactly what matters | Why does streaming need a new state? Why four states? | Split the already-understood doubled quote. Keep the unfinished field and pending decision visible. Name the distinctions only after showing their different next actions. | Empty field in Start versus empty contents in Quoted; same quoted input with another chunk cut. |
| Delivery is not completion | Is an empty current chunk an error or EOF? Does CRLF deliver twice? | Contrast a temporary cut with a separate final completion signal. Hold the CR flag until LF arrives and hand over the record once. | Final EOF inside quotes, final bare field, CR followed by the wrong byte, CR/LF inside quotes. |
| Preserve the actual text | Is every byte a character? Where does an error point? | Magnify the two bytes of é. Retain the incomplete prefix, then show a validated complete string. Error labels identify source byte positions and rejected records. | Move every cut, including UTF-8 and CRLF cuts; repeat with malformed inputs. |
| One record at a time | Does one read equal one record? What do nested Option/Result outcomes mean? | Show buffer capacity, filled prefix, next unread position and record delivery as different things. Reveal the record/error/end outcomes with the spoken names. | Unread suffix after a yielded record; short refill; final record without a terminator; read failure. |
| Put meaning at the right boundary | Where do files, headers, integers and business rules belong? | Keep the decoder's input/output agreement visible while exchanging the input source. Convert a completed text field into an application value outside the CSV decoder. | Header mismatch, missing field, invalid quantity, negative quantity, then a text note instead of a number. |
| Put it together | Can the decisions be combined and reused? | Use a fresh input combining empty fields, doubled quotes, a quoted newline, UTF-8 and CRLF. Pause for prediction, resolve the table, then move only the delivery cuts. | Contrast CSV with length-prefixed messages: retain the boundary principle while changing the format rules. |

## Revisions made during review

- Replaced the prior film's static scene renderer with Motion Canvas. Glyph motion, quote pairing, changing field height, record handoff, code extraction and selection are continuous animation operations.
- Slowed the initial narration candidate and used short spoken turns with deliberate pauses. Word alignment places the opening counts and iterator outcome reveals at their spoken referents.
- Mapped displayed Rust to exact file excerpts, including surrounding source context. Code selection precedes the relevant execution.
- Corrected crowded code/table layouts and completed-result sizing when the code panel opens.
- Fixed trace decoding on Windows so café remains café. Kept incomplete UTF-8 bytes from becoming replacement characters on screen.
- Removed stale waiting/incomplete labels after final completion, UTF-8 validation and parser failure. A fresh replay clears old EOF and quote markers.
- Moved chunk labels above the source to avoid enlarged code panels covering them. Complete-input lookahead uses a next-byte label before streaming is introduced.
- Corrected floating-point rounding at the export endpoint so scene lengths do not acquire an extra frame.
- Review stills use fresh scene instances. Repeated preview seeks had retained drawing state; they were unsuitable as final pixel references.

## What these checks establish

Runnable checkpoints and Rust tests support implementation correctness within the stated dialect. Traces connect the main execution visuals to that implementation. Timed-action audits, caption checks, exported-frame comparisons and waveform comparisons check concrete aspects of synchronization and delivery.

They do not prove that every viewer will find the explanation effortless or entertaining. The model interface used for this production cannot hear audio, so a listening review is not claimed. Naturalness and engagement remain judgments for a listener. The film's concrete examples, local variations, short turns and explicit boundaries are the design response to the earlier feedback.
