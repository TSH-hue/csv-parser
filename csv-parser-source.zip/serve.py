from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**k):super().__init__(*a,directory=str(ROOT),**k)
    def log_message(self,*a):pass
    def send_head(self):
        self.byte_range=None
        path=Path(self.translate_path(self.path));m=re.fullmatch(r'bytes=(\d+)-(\d*)',self.headers.get('Range',''))
        if not m or not path.is_file():return super().send_head()
        size=path.stat().st_size;a=int(m[1]);b=min(int(m[2]) if m[2] else size-1,size-1)
        if a>=size or a>b:self.send_error(416);return None
        self.send_response(206);self.send_header('Content-Type',self.guess_type(str(path)));self.send_header('Accept-Ranges','bytes');self.send_header('Content-Range',f'bytes {a}-{b}/{size}');self.send_header('Content-Length',str(b-a+1));self.end_headers()
        f=path.open('rb');f.seek(a);self.byte_range=(a,b);return f
    def copyfile(self,src,dst):
        if self.byte_range is None:return super().copyfile(src,dst)
        n=self.byte_range[1]-self.byte_range[0]+1
        try:
            while n:
                b=src.read(min(n,65536))
                if not b:break
                dst.write(b);n-=len(b)
        except (ConnectionResetError,BrokenPipeError):pass
print('CSV film: http://127.0.0.1:8745',flush=True)
ThreadingHTTPServer(('127.0.0.1',8745),Handler).serve_forever()
