from pathlib import Path
import json, math, subprocess
ROOT=Path(__file__).resolve().parent
def save(path,text):
    if not path.exists() or path.read_text(encoding='utf-8')!=text:path.write_text(text,encoding='utf-8')
scenes=json.loads((ROOT/'script.json').read_text())
variants={
 'noah':'Noah','unquoted':'Mira,bread, milk','empty_file':'','blank':'\n','trailing':'Mira,','terminal':'Mira\n','leading':',tea',
 'valid_quote':'Mira,"tea"','bare_quote':'Mira,tea"time','space_quote':'Mira, "tea"','empty_quote':'""',
 'quote_more':'"tea""time"','quote_end':'"tea"','quote_invalid':'"tea"x','bare_final':'Mira,tea',
 'bad_cr':'Mira,tea\rx','quoted_cr':'"top\r\nbottom"','quantity_negative':'name,quantity\nMira,-3',
 'invalid_utf8_display':'Mira,café','consumer_complete':'Mira,tea\nNoah,milk\n',
 'decoder_record':'Noah,"say "\n',
}
input_cases=[dict(id=s['id'],source=s['source']) for s in scenes]+[dict(id=k,source=v) for k,v in variants.items()]
(ROOT/'trace-inputs.json').write_text(json.dumps(input_cases),encoding='utf-8')
result=subprocess.run(['cargo','run','--quiet','--example','trace','--','trace-inputs.json'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',check=True)
(ROOT/'film-traces.json').write_text(result.stdout,encoding='utf-8')
actual=ROOT/'script-timeline.json'
if actual.exists() and len(json.loads(actual.read_text())['scenes'])==len(scenes):
    data=json.loads(actual.read_text())
else:
    start=0; timed=[]
    for s in scenes:
        t=.65;cues=[]
        for p in s['parts']:
            duration=len(p['text'].split())*60/170
            cues.append(dict(p,start=t,spoken_end=t+duration,end=t+duration+p['pause']))
            t+=duration+p['pause']
        duration=math.ceil(t*30)/30
        timed.append(dict(s,start=start,duration=duration,cues=cues));start+=duration
    data=dict(fps=30,duration=start,scenes=timed,estimated=True)
(ROOT/'film-timeline.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
directory=ROOT/'src/scenes/film';directory.mkdir(parents=True,exist_ok=True)
imports=[];names=[]
for i,s in enumerate(scenes):
    name=f'film{i:02}'
    save(directory/f'{s["id"]}.tsx',f"import {{makeScene2D}} from '@motion-canvas/2d';\nimport {{runFilmScene}} from '../../film';\nexport default makeScene2D(function*(view){{yield* runFilmScene(view,{i});}});\n")
    imports.append(f"import {name} from './scenes/film/{s['id']}?scene';");names.append(name)
save(ROOT/'src/full-project.ts',"import {makeProject} from '@motion-canvas/core';\n"+'\n'.join(imports)+"\nexport default makeProject({experimentalFeatures:true,scenes:["+','.join(names)+"]});\n")
print('Prepared',len(scenes),'film scenes,',len(input_cases),'Rust traces;',round(data['duration']/60,2),'minutes', '(estimated)' if data.get('estimated') else '(recorded)')
