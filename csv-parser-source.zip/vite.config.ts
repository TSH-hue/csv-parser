import {defineConfig} from 'vite';
import motionCanvas from '@motion-canvas/vite-plugin';
import ffmpeg from '@motion-canvas/ffmpeg';

export default defineConfig({
  plugins: [(motionCanvas as any).default({project:['./src/project.ts','./src/full-project.ts'],output:'./renders'}),(ffmpeg as any).default()],
  server:{host:'127.0.0.1',port:9010,watch:{ignored:['**/checkpoint-build/**','**/target/**','**/renders/**','**/review/**','**/audio/**','**/.voice-models/**','**/*.exe','**/*.pdb','**/*.wav','**/index.html','**/*.md','**/player-data.json','**/*-verification.json','**/captions.*','**/csv-parser-source.zip']}},
});
