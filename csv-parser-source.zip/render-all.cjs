const {chromium}=require('C:/Users/fedas/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),crypto=require('node:crypto');
const timeline=JSON.parse(fs.readFileSync('film-timeline.json'));
if(timeline.estimated)throw Error('Cannot render the final film against estimated narration.');
const sources=['src/film.tsx','src/visual.tsx','src/full-render.ts','film-timeline.json','film-traces.json','code-catalog.json'];
const digest=()=>{const h=crypto.createHash('sha256');for(const f of sources)h.update(fs.readFileSync(f));return h.digest('hex')};
const signature=digest();
const port=Number(process.env.MC_PORT||9010);
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'msedge',args:['--disable-background-timer-throttling','--disable-renderer-backgrounding']});
 const page=await browser.newPage({viewport:{width:1920,height:1080}});const errors=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{const msg=m.text();if(msg.startsWith('FRAME')||msg.startsWith('RENDER_RESULT'))console.log(msg);if(msg.includes('"level":"error"'))errors.push(msg)});
 fs.mkdirSync('renders',{recursive:true});const results=[];
 const chosen=process.argv[2]?process.argv[2].split(',').map(Number):timeline.scenes.map((_,i)=>i);
 for(const i of chosen){
   const scene=timeline.scenes[i],file=`renders/${scene.id}.mp4`,meta=`renders/${scene.id}.json`;
   if(digest()!==signature)throw Error('Animation changed during rendering. Stop and restart against a consistent version.');
   if(fs.existsSync(file)&&fs.existsSync(meta)&&JSON.parse(fs.readFileSync(meta)).signature===signature){console.log('Cached',scene.id);continue;}
   errors.length=0;const start=Date.now();
   await page.goto(`http://127.0.0.1:${port}/full-render.html?scene=${i}`);await page.waitForFunction(()=>window.ready,null,{timeout:60000});
   await page.evaluate(()=>mc.render());const status=await page.evaluate(()=>result);
   if(status!==0||errors.length)throw Error(`${scene.id}: ${JSON.stringify({status,errors})}`);
   const record={id:scene.id,duration:scene.duration,signature,renderSeconds:(Date.now()-start)/1000};
   fs.writeFileSync(meta,JSON.stringify(record,null,2));results.push(record);console.log('Completed',scene.id,record.renderSeconds+'s');
 }
 fs.writeFileSync(`render-report-${port}.json`,JSON.stringify({signature,results},null,2));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
