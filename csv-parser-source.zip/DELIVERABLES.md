# When a Comma Is Not a Separator

**37:29 · 1920×1080 · 30 fps · 10 chapters**

- [Watch the chaptered lesson locally](http://127.0.0.1:8745/)
- [Full narrated MP4](when-a-comma-is-not-a-separator.mp4)
- [Source, checkpoints and offline lesson package](csv-parser-source.zip)
- [SubRip captions](captions.srt) · [WebVTT captions](captions.vtt)
- [Transcript](TRANSCRIPT.md) · [Chapter timestamps](chapters.txt)
- [Run the examples or keep an offline copy](README.md)
- [Exact format policy](DIALECT.md) · [Sources and verification notes](VIDEO-NOTES.md)

The animation follows source text into fields and records, turns doubled source quotes into one content quote, preserves unfinished work across input chunks, and connects those decisions to the corresponding Rust excerpts. The final example combines the rules before transferring the boundary principle to another format.

The MP4 passed full decoding, 234 frame comparisons and 224 audio-window comparisons. The player passed all chapter seeks and final playback. Rust tests and the extracted package checks passed.

Movie SHA-256:
`72485a9687c299b6c97ac7e25e0a7112bb1203f55419ded2a5aa8da1eaf398f3`
