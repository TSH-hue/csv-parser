const {chromium}=require('C:/Users/fedas/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs');
(async()=>{
 const b=await chromium.launch({headless:true,channel:'msedge',args:['--disable-background-timer-throttling','--disable-renderer-backgrounding']});
 const p=await b.newPage({viewport:{width:1920,height:1080}});
 p.on('console',m=>console.log(m.text()));p.on('pageerror',e=>console.log('PAGE_ERROR',e.message));
 await p.goto('http://127.0.0.1:9010/render.html');
 await p.waitForFunction(()=>window.ready,{timeout:60000});
 fs.mkdirSync('review',{recursive:true});
 if(process.argv.includes('--render')) {
   const t=Date.now();await p.evaluate(()=>mc.render());console.log('Render ms',Date.now()-t,await p.evaluate(()=>result));
 }else{
   for(const t of [1,12,19,27,34,43,52]){
     await p.evaluate(t=>mc.frame(t),t);await p.screenshot({path:`review/prototype-${t}.png`});
   }
 }
 await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
