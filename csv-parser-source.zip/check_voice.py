"""Transcribe every short spoken turn. Cache by audio digest; no listening claim.
Word timings are retained for captions and motion anchors.
"""
from pathlib import Path
import sys,json,hashlib,time,difflib,re
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'json-v2/.media-tools'))
from faster_whisper import WhisperModel
model=WhisperModel('base.en',device='cpu',compute_type='int8',cpu_threads=4,download_root=str(ROOT.parent/'json-v2/.media-models'),local_files_only=True)
scenes=json.loads((ROOT/'script.json').read_text(encoding='utf-8'))
out=ROOT/'audio-review';out.mkdir(exist_ok=True)
def norm(text):return re.findall(r'[a-z0-9]+',text.lower())
results=[]
for scene in scenes:
    for index,part in enumerate(scene['parts']):
        speed=part.get('speed',.86)
        key=hashlib.sha256(('af_heart'+str(speed)+part['text']).encode()).hexdigest()[:12]
        audio=ROOT/f'audio/{scene["id"]}-{index}-{key}.wav'
        deadline=time.monotonic()+3600
        while not audio.exists() or audio.stat().st_size<100:
            if time.monotonic()>deadline:raise RuntimeError(f'Audio never appeared: {audio}')
            time.sleep(2)
        # A generated wave is written once. Wait briefly for the write to finish.
        size=audio.stat().st_size;time.sleep(.15)
        if audio.stat().st_size!=size:time.sleep(.5)
        dest=out/(audio.stem+'.json')
        if dest.exists():result=json.loads(dest.read_text(encoding='utf-8'))
        else:
            segments,info=model.transcribe(str(audio),language='en',beam_size=3,word_timestamps=True,vad_filter=False,condition_on_previous_text=False)
            segments=list(segments);heard=' '.join(s.text for s in segments)
            words=[dict(start=w.start,end=w.end,text=w.word,probability=w.probability) for s in segments for w in s.words]
            matcher=difflib.SequenceMatcher(None,norm(part['text']),norm(heard),autojunk=False)
            aa=norm(part['text']);bb=norm(heard)
            differences=[dict(expected=' '.join(aa[a:b]),heard=' '.join(bb[c:d])) for tag,a,b,c,d in matcher.get_opcodes() if tag!='equal']
            result=dict(scene=scene['id'],part=index,audio=str(audio.relative_to(ROOT)),expected=part['text'],transcribed=heard,similarity=matcher.ratio(),differences=differences,words=words)
            dest.write_text(json.dumps(result,indent=2),encoding='utf-8')
        results.append(result)
        print(scene['id'],index,round(result['similarity'],3),flush=True)
(ROOT/'audio-review.json').write_text(json.dumps(dict(model='base.en',results=results),indent=2),encoding='utf-8')
