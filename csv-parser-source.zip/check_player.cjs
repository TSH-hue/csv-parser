const {chromium}=require('C:/Users/fedas/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'msedge'});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8745/',{waitUntil:'networkidle'});
 await page.waitForFunction(()=>window.lesson);
 await page.locator('video').evaluate(v=>new Promise((resolve,reject)=>{
  if(v.readyState>=1)resolve();else{v.onloadedmetadata=resolve;v.onerror=()=>reject(v.error.message)}
 }));
 const data=await page.evaluate(()=>lesson);
 const metadata=await page.locator('video').evaluate(v=>({duration:v.duration,width:v.videoWidth,height:v.videoHeight,tracks:v.textTracks.length}));
 if(metadata.width!==1920||metadata.height!==1080||Math.abs(metadata.duration-data.duration)>.1)throw Error(JSON.stringify(metadata));
 await page.locator('video').evaluate(v=>{v.muted=true});
 await page.locator('track').evaluate(t=>{t.track.mode='showing'});
 await page.waitForFunction(()=>document.querySelector('track').readyState===2,null,{timeout:60000});
 const captionCount=await page.locator('track').evaluate(t=>t.track.cues.length);
 await page.locator('track').evaluate(t=>{t.track.mode='hidden'});
 if(captionCount!==data.captions)throw Error('Missing captions');
 if(await page.locator('.chapter').count()!==10)throw Error('Missing chapters');
 await page.locator('.chapter').nth(4).click();
 await page.waitForFunction(()=>Math.abs(document.querySelector('video').currentTime-lesson.chapters[4].start)<5);
 await page.locator('#steps').click();
 if(!await page.locator('dialog').isVisible())throw Error('Step view absent');
 const before=await page.locator('#stepText').textContent();
 await page.locator('#next').click();
 if(before===await page.locator('#stepText').textContent())throw Error('Next step did not change');
 await page.locator('#stepImage').evaluate(img=>new Promise((r,j)=>{
  if(img.complete&&img.naturalWidth)r();else{img.onload=r;img.onerror=j}
 }));
 await page.locator('#previous').click();
 if(before!==await page.locator('#stepText').textContent())throw Error('Previous step wrong');
 await page.locator('#watchStep').click();
 if(await page.locator('dialog').isVisible())throw Error('Step dialog did not close');
 await page.locator('video').evaluate(v=>v.pause());
 await page.locator('#search').fill('quote');
 const searchCount=await page.locator('.turn').count();
 if(searchCount<20||searchCount>=data.parts.length)throw Error('Transcript filtering failed');
 await page.locator('.turn').first().click();
 await page.locator('video').evaluate(v=>v.pause());
 await page.locator('#file').selectOption('checkpoints/04_lookahead.rs');
 await page.waitForFunction(()=>document.querySelector('#code').textContent.includes('peekable'));
 const resources=await page.evaluate(async()=>{
  const links=[...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href'));
  return Promise.all(links.map(async url=>({url,status:(await fetch(url,{method:'HEAD'})).status})));
 });
 if(resources.some(r=>r.status!==200))throw Error(JSON.stringify(resources));
 const images=await page.evaluate(async()=>{
  const out=[];for(const p of lesson.parts){const response=await fetch(p.image,{method:'HEAD'});if(response.status!==200)out.push(p.image)}return out;
 });
 if(images.length)throw Error('Missing step images: '+images.join(','));
 await page.locator('#search').fill('');
 await page.locator('#file').selectOption('rust/lib.rs');
 await page.waitForFunction(()=>document.querySelector('#code').textContent.includes('pub struct Decoder'));
 await page.screenshot({path:'player-desktop.png',fullPage:true});
 await page.setViewportSize({width:390,height:844});
 const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
 if(overflow)throw Error('Mobile overflow');
 await page.screenshot({path:'player-mobile.png',fullPage:true});
 const played=[];
 for(let i=0;i<10;i++){
  await page.locator('.chapter').nth(i).click();
  await page.waitForFunction(start=>{const v=document.querySelector('video');return v.readyState>=3&&v.currentTime>=start&&v.currentTime<start+5},data.chapters[i].start);
  await page.locator('video').evaluate(v=>{v.playbackRate=2;return v.play()});
  await page.waitForTimeout(700);
  const state=await page.locator('video').evaluate(v=>({time:v.currentTime,ready:v.readyState,error:v.error?.message||null}));
  if(state.error||state.time<=data.chapters[i].start)throw Error(JSON.stringify(state));
  played.push(state);
 }
 await page.locator('video').evaluate(v=>{v.currentTime=v.duration-1;return v.play()});
 await page.waitForFunction(()=>document.querySelector('video').ended,null,{timeout:10000});
 if(errors.length)throw Error(JSON.stringify(errors));
 fs.writeFileSync('player-verification.json',JSON.stringify({metadata,chapters:10,captionCount,searchCount,resources,stepImages:224,played,ended:true,mobileOverflow:overflow,errors},null,2));
 await browser.close();console.log('Player, all chapters, captions, sources, 224 step images, transcript search, end playback and mobile layout passed.');
})().catch(e=>{console.error(e);process.exit(1)});
