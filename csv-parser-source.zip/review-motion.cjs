const {chromium}=require('C:/Users/fedas/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs');
const timeline=JSON.parse(fs.readFileSync('film-timeline.json'));
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'msedge'});
 const page=await browser.newPage({viewport:{width:1920,height:1080}}),checks=[];
 const cases=[{index:0,action:'split',word:'one',times:[.12,.36,.60]},
              {index:9,action:'merge',times:[.50,.75,1.10,1.40]},
              {index:13,action:'enum',times:[1.45,1.75,2.05]}];
 fs.mkdirSync('review/motion',{recursive:true});
 for(const item of cases){
  const scene=timeline.scenes[item.index],cue=scene.cues.find(c=>c.action===item.action);
  const base=item.word?cue.words.find(w=>w.text.toLowerCase().replace(/[^a-z]/g,'')===item.word).start:cue.start;
  for(const [index,offset] of item.times.entries()){
   const local=base+offset,file=`review/motion/${scene.id}-${item.action}-${index}.png`;
   await page.goto(`http://127.0.0.1:9010/full-render.html?scene=${item.index}`);
   await page.waitForFunction(()=>window.ready);
   await page.evaluate(t=>mc.frame(t),local);await page.screenshot({path:file});
   checks.push({scene:scene.id,action:item.action+'-motion-'+index,local,file});
  }
 }
 fs.writeFileSync('review/motion-checks.json',JSON.stringify(checks,null,2));
 await browser.close();console.log('Captured 10 intermediate motion references.');
})().catch(e=>{console.error(e);process.exit(1)});
