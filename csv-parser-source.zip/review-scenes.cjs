const {chromium}=require('C:/Users/fedas/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs');
const timeline=JSON.parse(fs.readFileSync('film-timeline.json'));
(async()=>{
 const b=await chromium.launch({headless:true,channel:'msedge',args:['--disable-background-timer-throttling','--disable-renderer-backgrounding']});const audits=[];
 const p=await b.newPage({viewport:{width:1920,height:1080}});const errors=[];
 p.on('console',m=>{if(m.text().includes('MC')||m.text().includes('RENDER_RESULT'))console.log(m.text());if(m.text().includes('"level":"error"'))errors.push(m.text())});p.on('pageerror',e=>errors.push(e.message));
 fs.mkdirSync('review/full',{recursive:true});
 const selection=process.argv[2]?process.argv[2].split(',').map(Number):timeline.scenes.map((_,i)=>i);
 for(const i of selection){
  const s=timeline.scenes[i];
  for(const c of s.cues){
   // A fresh scene avoids retained canvas/cache state across repeated seek renders.
   await p.goto(`http://127.0.0.1:9010/full-render.html?scene=${i}`);await p.waitForFunction(()=>window.ready,null,{timeout:60000});
   const t=Math.min(s.duration-.2,c.spoken_end-.25);await p.evaluate(t=>mc.frame(t),t);await p.screenshot({path:`review/full/${s.id}-${c.action}.png`});
  }
  audits.push(await p.evaluate(()=>window.__audit));
  fs.writeFileSync('review/timing-audit.json',JSON.stringify(audits,null,2));
  fs.writeFileSync('review/browser-errors.json',JSON.stringify(errors));
  console.log('Reviewed',s.id);
 }
 await b.close();fs.writeFileSync('review/timing-audit.json',JSON.stringify(audits,null,2));fs.writeFileSync('review/browser-errors.json',JSON.stringify(errors));if(errors.length)throw Error(errors.join('\n'));
})().catch(e=>{console.error(e);process.exit(1)});
