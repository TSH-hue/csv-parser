from pathlib import Path
import textwrap,json
ROOT=Path(__file__).resolve().parent

# Anchor each excerpt to the actual source file, preserving the whole file for
# the overview and downloadable code viewer. No invented helper names in film code.
SPECS={
 '03-field':('checkpoints/01_field.rs','let mut field =',4),
 '04-comma':('checkpoints/02_records.rs','let bytes =',3),
 '05-record':('rust/lib.rs',"b',' => self.end_field()?",6),
 '06-empty':('rust/lib.rs','if !self.started',6),
 '07-quoted-comma':('checkpoints/03_quoted.rs','} else if in_quotes',5),
 '08-quoted-newline':('checkpoints/03_quoted.rs','} else if in_quotes',3),
 '09-start-boundary':('checkpoints/04_lookahead.rs',"} else if byte == b'\"'",6),
 '10-doubled':('checkpoints/04_lookahead.rs',"if input.peek()",5),
 '11-after-quote':('checkpoints/04_lookahead.rs','} else if closed_quote',2),
 '12-lookahead-limit':('checkpoints/04_lookahead.rs',"if input.peek()",9),
 '13-state-memory':('rust/lib.rs',"State::QuoteSeen if byte == b'\"'",4),
 '14-four-states':('rust/lib.rs','pub enum State',6),
 '15-decoder':('rust/lib.rs','pub struct Decoder',11),
 '16-match':('rust/lib.rs','match self.state',9),
 '17-finish':('rust/lib.rs','if self.state == State::Quoted',11),
 '18-crlf':('rust/lib.rs','if self.after_cr',8),
 '19-utf8':('rust/lib.rs','fn end_field',10),
 '20-errors':('rust/lib.rs','pub struct CsvError',6),
 '21-split-test':('tests/streaming.rs','for cut in 0..=bytes.len()',6),
 '22-next-record':('checkpoints/06_reader.rs','for result in',4),
 '23-input-buffer':('rust/lib.rs','Ok(n) =>',5),
 '24-iterator':('rust/lib.rs','impl<R: Read> Iterator',9),
 '25-adapter-execute':('rust/lib.rs','match self.decoder.push',10),
 '26-final-and-io':('rust/lib.rs','Ok(0) =>',13),
 '27-source-boundary':('rust/lib.rs','pub struct Records<R>',8),
 '28-schema':('checkpoints/07_application.rs','let record = result?',9),
 '15-push-signature':('rust/lib.rs','pub fn push',4),
 '16-open':('rust/lib.rs',"State::Start if byte == b'\"'",3),
 '16-contents':('rust/lib.rs','State::Quoted =>',8),
 '16-quote':('rust/lib.rs',"State::QuoteSeen if byte == b'\"'",4),
 '16-separators':('rust/lib.rs',"b',' => self.end_field()?",10),
 '20-offset':('rust/lib.rs','let at = self.offset',2),
 '20-propagate':('rust/lib.rs',"b'\\n' => {",4),
 '20-close':('rust/lib.rs','fn error(&mut self',4),
}

def catalog():
    out={}
    for id,(file,anchor,count) in SPECS.items():
        full=(ROOT/file).read_text(encoding='utf-8');lines=full.splitlines()
        start=next(i for i,line in enumerate(lines) if anchor in line)
        snippet=textwrap.dedent('\n'.join(lines[start:start+count]))
        out[id]=dict(path=file,full=full,start=start,end=start+count,code=snippet)
    return out

if __name__=='__main__':
    result=catalog();(ROOT/'code-catalog.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('Mapped',len(result),'excerpts to source files')
