"""Authored spoken turns, source examples, code origins, and animation intentions.
Each action is a screen change, not an automatically chosen illustration.
"""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SCENES=[]

def scene(id, chapter, title, source, mode, turns, code='', focus=None, note=''):
    parts=[]
    for line in turns.strip().split('\n'):
        action,text=line.split('|',1)
        parts.append(dict(action=action.strip(),text=text.strip(),pause=1.0 if action.strip() not in ['predict','checkpoint'] else 3.0))
    SCENES.append(dict(id=id,chapter=chapter,title=title,source=source,mode=mode,parts=parts,code=code,focus=focus or [],editorial_note=note))

scene('01-import','01 · The useful result','Two cells. One troublesome comma.','Mira,"bread, milk"','opening','''
source | Mira has a shopping note: bread, milk. We want to import her name and her note into these two cells.
table | The text above is C S V: comma separated values. Each cell is a field. A row of related fields is a record.
split | Let's try the obvious solution. Split the text whenever we see a comma. There. One piece, two pieces, three pieces.
wrong | Wait, three? The note has been cut in half. Bread and milk were supposed to stay together in one cell.
compare | Look at the two commas. Same character. Different jobs. The first separates fields. The second belongs to the note.
quotes | The quotes tell us which is which. They surround a field whose contents are allowed to include a comma.
resolve | Our job is to recover the two original values, keeping the comma in the note and leaving out the surrounding quotes.
''',note='The intended table must appear before the bad split; preserve exact source positions in both results.')

scene('02-promise','01 · The useful result','Build the decisions, then keep them working.','Mira,"bread, milk"','roadmap','''
source | We'll build that reader together in Rust, one working case at a time. You can follow the whole film without typing.
grow | First, we'll make fields and records. Then we'll see what quotes change, including a quote that belongs inside the text.
cut | Finally, the input will arrive in pieces. We'll keep the same answers even when a piece ends at an awkward spot.
code | Every time we need a new decision, we'll add the small piece of Rust that makes it, and run the same example.
checkpoint | The source links include working checkpoints. Pause at a checkpoint if you'd like to build along; the next explanation won't depend on doing homework.
contract | This reader has a stated set of rules. It reads UTF eight text, accepts line feed or carriage return plus line feed between records, and reports malformed quoting.
start | We'll introduce those details when they change a decision. For now, let's earn our first field with just four letters.
''',note='No wall of final code in the opening. Show a compact route whose stages become concrete immediately.')

scene('03-field','02 · From bytes to records','Build one field.','Mira','field','''
source | Start with Mira. No comma yet. The answer is one field containing the four letters we can already see.
empty | But the program receives a sequence, so it needs somewhere to keep the part it has read. Start an empty field.
consume | Take M. Keep it. Take i, then r, then a. Each new byte joins the same unfinished field.
code | This becomes a vector of bytes in Rust. A vector can grow. Each push appends one byte to its end.
loop | The loop borrows the input slice and visits its bytes. The little ampersand in the pattern gives us the byte value to push.
eof | When the input really ends, the field is complete. These four bytes form the string Mira. Now we can return that value.
variation | Try Noah instead. The letters changed, but the operation didn't. We accumulate content until something tells us the field is finished.
''','let mut field = Vec::new();\nfor &byte in input {\n    field.push(byte);\n}',[0,1,2],note='No floating buffers unrelated to the table: the unfinished cell is the growing field.')

scene('04-comma','02 · From bytes to records','A separator finishes a field.','Mira,tea','plain','''
source | Now add a comma and tea. We want two fields in the same record. The comma itself is not part of either value.
consume | Read Mira as before. When we reach the comma, the field has everything it needs. We can close that cell.
finish_field | Put the finished string into the current record, then start an empty field for tea. Keep the record right here.
code | In Rust, the record is another vector. Its elements are strings, because it holds complete field values rather than individual bytes.
take | Memory take moves the current vector out and leaves an empty one behind. We can reuse the field variable without copying its whole contents.
append | Convert the bytes into a string, then push it into the record. The question mark passes any conversion error back to the caller.
eof | At final end of input, finish tea as well. There was no comma after it, so the end itself supplies the finishing event.
''','let bytes = std::mem::take(&mut field);\nlet text = String::from_utf8(bytes)?;\nrow.push(text);',[0,1,2],note='Explain take as ownership transfer, not memory-layout fiction. Result conversion will receive its error type later.')

scene('05-record','02 · From bytes to records','A record boundary does two jobs.','Mira,tea\nNoah,milk','records','''
source | Add a second shopper on a new line. L F labels the line-break byte on screen. Each shopper needs a separate record.
consume | The first comma still finishes Mira. The line break arrives after tea, while tea is still in the field we are building.
finish_field | So a record boundary first finishes that last field. Only then is the whole record ready to hand over.
deliver | Move the completed row out. Start an empty record. Noah and milk will go into that new record, not into Mira's.
code | These repeated actions deserve names: end field, and end record. Each name stands for one job we already understand visually.
boundary | Notice their boundary. End field doesn't decide whether a comma was allowed. It packages the field after the scanning logic makes that decision.
variation | Replace tea with coffee. Nothing about record handling changes. Separate the decision about a boundary from the work performed when one is found.
''','b\',\' => self.end_field()?,\nb\'\\n\' => {\n    self.end_field()?;\n    return Ok(Some(self.end_record()));\n}',[0,2,3],note='Introduce helper abstraction at repetition. The first complete record leaves the working row visibly.')

scene('06-empty','02 · From bytes to records','Empty is a value; absent is different.','Mira,\n,tea','empty','''
source | What should this trailing comma mean? Mira has a second field, but there is no text in it. The answer includes an empty string.
empty | The field builder is already empty. We still finish it when the record ends, so the empty cell keeps its place.
leading | On the next line, the comma comes first. Same operation. Finish an empty first field, then read tea into the second.
blank | A blank line represents one record containing one empty field. It has a record boundary, even though it has no field text.
none | A completely empty file is a different case. In this reader, it produces no records. We haven't started a record at all.
terminal | And a line break after a completed record does not create an extra imaginary row. There must be a new record to finish.
checkpoint | That's our plain-text checkpoint: content fills a field, a comma closes a field, and a record boundary closes the last field and the record.
''','if !self.started {\n    return Ok(None);\n}\nself.end_field()?;\nOk(Some(self.end_record()))',[0,3,4],note='Show four tiny inputs separately; explicitly distinguish this chosen empty-file policy from the exercise.')

scene('07-quoted-comma','03 · The punctuation changes jobs','Inside the quotes, keep the comma.','Mira,"bread, milk"','quoted','''
source | Now return to the input that broke our split. Mira is ordinary. The next field starts with a quote.
open | Opening that quote changes how we read the field. The contour marks the part we're reading as quoted contents.
consume | Bread goes into the field. Then comes the comma. We're still inside the quoted field, so this comma goes into the contents too.
close | At the closing quote, we stop reading quoted contents. The surrounding quotes describe the format; they aren't copied into the value.
resolve | We finish with two cells. Mira, and bread comma milk. The inner comma has reached the exact place it belongs.
code | Our first version can remember inside quotes with a boolean. The comma branch only separates fields when that boolean is false.
variation | Remove the quotes around bread and milk, and the inner comma becomes a separator again. Punctuation gets its job from context.
''','if in_quotes {\n    field.push(byte);\n} else if byte == b\',\' {\n    end_field();\n}',[0,1,2,3],note='This excerpt is the comma decision only; surrounding quote recognition lives in the full checkpoint.')

scene('08-quoted-newline','03 · The punctuation changes jobs','One field can contain a line break.','Mira,"top\nbottom"\n','multiline','''
source | Suppose the note has two lines: top, then bottom. That's still one shopper and one note, so it must remain one record.
inside | The line break arrives while the field is quoted. Watch the cell grow vertically. Bottom belongs below top inside that same cell.
outside | After the closing quote, another line break arrives. This one finishes the record. Same byte, different context again.
code | We don't need a special rule for every allowed content character. Inside quotes, an ordinary byte is simply added to the field.
abstraction | That's a useful abstraction we've earned. Quoted content is one category. The only byte needing a new decision inside it is a quote.
variation | A comma, a space, and a line break all travel through the content path here. Their shapes differ; their job is the same.
checkpoint | Our second working agreement is simple: inside quotes, preserve contents. Outside quotes, separators can finish fields and records. Now let's challenge the quote itself.
''','State::Quoted => {\n    if byte == b\'"\' {\n        self.state = State::QuoteSeen;\n    } else {\n        self.field.push(byte);\n    }\n}',[0,4],note='Quoted/QuoteSeen names shown only when introduced later; initial explanation uses the corresponding in_quotes checkpoint.')

scene('09-start-boundary','03 · The punctuation changes jobs','Where may a quoted field begin?','Mira,tea"time','quote_rules','''
source | Before adding escapes, pin down where quoting starts. In our rules, an opening quote must be the first byte of a field.
valid | Here the comma finished Mira. The next field is empty and hasn't started. A quote here can open quoted contents.
invalid | But in tea quote time, we've already started a bare field. That quote cannot quietly change the interpretation of its earlier letters.
error | We report a quote in a bare field, at this source byte. The malformed current record won't be handed to the application.
space | Spaces also count as contents. A space before a quote has already started a bare field. This reader doesn't secretly trim it away.
boundary | These are format decisions, not guesses about what the writer intended. A stated rule gives us a clear result and a clear error.
variation | A field beginning with two quotes is different: it can be an empty quoted field. There was no bare content before the opening quote.
''','State::Start if byte == b\'"\' => {\n    self.state = State::Quoted;\n}\nState::Bare if byte == b\'"\' => {\n    return Err(quote_in_bare_field);\n}',[0,3,4],note='Keep error highlighting anchored at offending byte. Source excerpt may use teaching aliases, marked and linked to final code.')

scene('10-doubled','04 · A quote inside the value','Two marks in the source, one in the value.','Noah,"say ""hi"""','doubled','''
source | Noah's note is say, then hi in quotation marks. We want those inner quote characters to survive in the field value.
encode | C S V writes a content quote as two consecutive quotes inside the quoted field. These two source marks represent one character.
first | Read the first mark of the pair. If we immediately declare the field closed, the second quote becomes a problem.
lookahead | Instead, inspect the next byte. It's another quote. That tells us this pair belongs to the contents, not the field boundary.
merge | Bring the two marks together. Append one quote. Then keep reading the same field. The h and i come next.
repeat | The pair after hi works exactly the same way. It adds the second content quote, the one after hi in the note.
close | One final quote remains. It closes the field. Three adjacent marks can be a doubled content quote followed by a closing quote.
''','if next_byte == Some(b\'"\') {\n    field.push(b\'"\');\n    skip_the_second_quote();\n}',[0,1,2],note='Make source pairs merge in flight; distinguish the final unpaired closing quote without color alone.')

scene('11-after-quote','04 · A quote inside the value','The following byte resolves the question.','"tea",milk','after_quote','''
source | Let's slow down the decision at one quote. We've read tea inside a quoted field and now reached a quote mark.
candidate_quote | If the following byte is another quote, keep one quote in the text and continue reading quoted contents.
candidate_comma | If it's a comma, the quote we just saw was the closing quote. Finish tea, then begin the next field.
candidate_eof | A record ending can finish the record. Final end of input can finish the last field. Those are legal ways to complete it.
invalid | But an x right after the closing quote has no job in this format. It is neither an escaped quote nor a separator.
error | Report that x as an unexpected character after a quote. We don't discard it, and we don't quietly merge it into tea.
generalize | So a quote doesn't answer the whole question by itself. The next byte decides which interpretation fits. That's the context we must preserve.
''','State::QuoteSeen if byte == b\'"\' => {\n    self.field.push(b\'"\');\n    self.state = State::Quoted;\n}',[0,1,2],note='Present alternatives sequentially and keep only current one prominent; no unexplained state diagram.')

scene('12-lookahead-limit','04 · A quote inside the value','What if there is no next byte yet?','Noah,"say ""hi"""','lookahead','''
source | With the entire input in memory, our checkpoint can peek at the next byte. That lets us handle the doubled quote directly.
code | Peek observes the next byte without consuming it. If it is another quote, we consume that second mark and append one quote.
execute | Run Noah's note. The pair before hi becomes one mark, the pair after hi becomes another, and the final mark closes the field.
cut | Now put a delivery boundary between the two marks in the first pair. The current piece ends just after the first quote.
missing | Peek has no byte to show. But the file hasn't necessarily ended. Its next piece may begin with exactly the quote we need.
problem | We can't decide that the field is closed just because this piece is empty. And we can't forget the letters already collected.
checkpoint | The complete-input version has taught us the decision. To stream, we need to preserve an unanswered decision until more input arrives.
''','match input.peek() {\n    Some(b\'"\') => { /* escaped quote */ }\n    _ => { /* closing quote */ }\n}',[0,1,2],note='Show this as the complete-input checkpoint, not valid streaming code. Its missing-next-byte assumption is the new problem.')

scene('13-state-memory','05 · Remember exactly what matters','Keep the field and the unresolved decision.','Noah,"say ""hi"""','stream_quote','''
source | Keep the same source. We have Noah in the record and say in the unfinished note. The first quote of the pair has arrived.
cut | The chunk ends here. Leave the record and field exactly where they are. Only the available input has run out.
remember | We also need one fact: we saw a quote inside quoted contents, and the next byte must tell us what it means.
name | Give that situation a name: Quote Seen. The name records a question still waiting for an answer. It doesn't mean the field is finished.
arrive | Here comes the next chunk. Its first byte is another quote. Now we can resolve the question without rereading the earlier text.
merge | The pair contributes one quote to the field. Switch back to reading quoted contents, ready for h, i, and whatever follows.
generalize | We kept exactly the information needed for the next decision. Chunk boundaries can move; the meaning of the bytes stays the same.
''','State::QuoteSeen if byte == b\'"\' => {\n    self.field.push(b\'"\');\n    self.state = State::Quoted;\n}',[0,1,2],note='Adapt the reviewed hardest-scene prototype. Moving chunk boundaries must never alter the source or output.')

scene('14-four-states','05 · Remember exactly what matters','Four situations, four enum variants.','a,"b"','state_build','''
start | What other situations must survive between bytes? Before any content in a field, we're at Start. An opening quote is allowed here.
bare | After ordinary unquoted content begins, we're in Bare. Commas and record endings can finish it, but a quote here is an error.
quoted | After an opening quote, we're in Quoted. Commas and line breaks are content. A quote takes us to the pending decision.
quote_seen | That pending situation is Quote Seen. Another quote adds one content quote; a legal separator closes the field or record.
enum | These are alternatives, so Rust gives us an enum. The state variable holds one variant at a time, matching our one current situation.
reason | We didn't start by inventing four boxes. Each variant preserves a distinction that changed what the next byte was allowed to do.
variation | Compare an empty bare field with an empty quoted field. Their text can be identical, but their next legal actions differ. Contents alone aren't enough.
''','enum State {\n    Start,\n    Bare,\n    Quoted,\n    QuoteSeen,\n}',[1,2,3,4],note='Derive variants from four source snapshots. Never show the full transition web before its meaning.')

scene('15-decoder','05 · Remember exactly what matters','The state belongs with the unfinished work.','Noah,"say "','decoder','''
source | Our local variables used to disappear when the parsing function returned. But waiting for another chunk must not erase unfinished work.
group | Put the state, field bytes, and current record into a Decoder. This struct keeps them together across calls.
method | Its push method accepts one byte; u eight is Rust's one-byte integer. The mutable borrow lets this call update the decoder's unfinished work.
none | Most bytes don't complete a record. After an ordinary letter, push returns a successful result containing None: no record ready yet.
some | At a record boundary, it returns Some with the completed record. The record moves out; the decoder is ready to build the next one.
error | A malformed byte returns an error instead. Result separates success from failure. Inside success, Option separates a ready record from unfinished work.
boundary | This is our core's boundary: one byte in, a state update, and possibly one complete record out. It needs no file handle or application schema.
''','struct Decoder {\n    state: State,\n    field: Vec<u8>,\n    row: Vec<String>,\n}\nfn push(&mut self, byte: u8)\n    -> Result<Option<Record>, CsvError>',[0,1,2,3,5,6],note='Record alias shown as Vec<String> before shorthand. Other bookkeeping fields introduced in their own scenes.')

scene('16-match','05 · Remember exactly what matters','Execute the current state, then the byte.','Mira,"bread, milk"','state_execute','''
source | Run the original shopping note through this decoder. After Mira and the separating comma, we're at Start for the second field.
open | A quote at Start switches to Quoted. It doesn't push a quote into the field. It only changes how following bytes will be read.
contents | In Quoted, bread, the comma, the space, and milk all take the content path. Watch the current line and the growing cell together.
quote | The next quote switches to Quote Seen. It adds no content yet. At final end of input, that quote can legally close the field.
code | Rust's match selects the arm for the current state. An if guard narrows an arm to a particular next byte, such as another quote.
fallthrough | Once the special quote cases are handled, the common separator branch can finish a field or record. That work doesn't need to be duplicated.
checkpoint | We now have a byte-driven decoder. Feed the same input in one piece or several pieces; keep the decoder, and it keeps the decisions consistent.
''','match self.state {\n    State::Quoted => { /* contents or quote */ }\n    State::QuoteSeen if byte == b\'"\' => { /* one quote */ }\n    State::Start if byte == b\'"\' => { /* open */ }\n    State::Bare if byte == b\'"\' => { /* error */ }\n    _ => { /* separators or bare content */ }\n}',[2,3,1,5],note='Use overview only after all branches are familiar; replace comments with focused actual branch while executing.')

scene('17-finish','06 · Delivery is not completion','Only final EOF can finish the input.','Mira,"tea','eof','''
source | Consider this unfinished quoted note. We've read tea, but there is no closing quote. Now the current chunk ends.
chunk | Nothing is wrong yet. More bytes may arrive. Keep the Quoted state and the text tea, and wait for the next piece.
final | Now change just one fact: the input source says this is the final end. No more bytes will arrive. The closing quote is missing.
error | The finish method reports an unclosed quote. It points to the final byte position, where the missing continuation became certain.
valid | If the state had been Quote Seen instead, a closing quote was already available. Final end could finish that field and its record.
bare | A bare field can also finish at final end. A file does not need a line break after its last record in our chosen rules.
generalize | So push means here's a byte, and finish means there will never be another one. Don't use finish to mean please wait for the next chunk.
''','if self.state == State::Quoted {\n    return Err(unclosed_quote_at_eof);\n}\nif !self.started { return Ok(None); }\nself.end_field()?;\nOk(Some(self.end_record()))',[0,3,4,5],note='Contrast chunk exhaustion and final EOF on identical visible prefix. Explicit finish call only for the latter.')

scene('18-crlf','06 · Delivery is not completion','Two bytes can form one record boundary.','Mira,tea\r\nNoah,milk','crlf','''
source | Some files end a record with two bytes: carriage return, then line feed. On screen, C R and L F label those otherwise invisible bytes.
cr | Outside quotes, the carriage return finishes the last field, but our rules still require the following line feed before delivering the record.
cut | Put a chunk boundary between them. Keep the completed fields, and remember that we are waiting for line feed. Nothing is delivered twice.
lf | When line feed arrives, clear that pending flag and deliver the record once. Start the next record after the pair.
code | This flag is separate from the four field states. It records a pending record ending, after field processing has already done its job.
invalid | If another byte arrives instead, report an error at that byte. If final end arrives, report the missing line feed at final end.
inside | Inside a quoted field, both bytes are contents. The quoted path keeps them exactly. Our line-ending rule only applies outside quotes.
''','if self.after_cr {\n    if byte != b\'\\n\' { return Err(expected_lf); }\n    self.after_cr = false;\n    return Ok(Some(self.end_record()));\n}',[0,1,2,3],note='Show CR and LF as two labeled bytes, not two literal source characters. Do not deliver before validating LF.')

scene('19-utf8','07 · Preserve the actual text','A chunk can even split a character.','Zoë,café','utf8','''
source | So far, our examples used mostly one-byte letters. Now import Zoë and café. The accent is part of the value and must survive unchanged.
bytes | UTF eight stores some characters in several bytes. Zoom into the final é: these two bytes belong to one character.
cut | A read may stop between them. If we turn each byte into a character immediately, we won't recover the original é correctly.
keep | Instead, keep raw content bytes in the field vector. The first byte waits there. The next chunk adds the remaining byte.
decode | When the field is complete, String from UTF eight validates the whole sequence and gives us the actual text café.
syntax | We can still recognize commas and quotes while scanning. A continuation byte in UTF eight cannot be the comma byte or the quote byte.
boundary | That gives us a clean boundary: the scan identifies field structure, and string conversion validates the completed text. A byte is not automatically a character.
''','field: Vec<u8>\n\nlet bytes = std::mem::take(&mut self.field);\nlet text = String::from_utf8(bytes)?;\nself.row.push(text);',[0,2,3,4],note='Animate C3 A9 joining to é, with labels explicitly bytes. Never draw half a Unicode character as a valid character.')

scene('20-errors','07 · Preserve the actual text','Tell the caller what failed, and where.','Mira,"tea"x','errors','''
source | A caller needs more than something went wrong. Here the x after the closing quote violates a specific rule at a specific source position.
position | Count source bytes from zero as push consumes them. Keep the current position before incrementing, so an error can point to the byte being examined.
kind | Store the error kind and its byte offset together. Rust's error enum names the failure; the error struct carries its location.
utf8 | Invalid UTF eight is detected when a field completes. Our small implementation points that error to the start of the source field, not a guessed character index.
question | The question mark after end field means: if this operation failed, return that error now. On success, continue with the next operation.
stop | After failure or final completion, mark the decoder closed. Accidentally feeding it again produces a closed error instead of continuing from damaged partial work.
boundary | The application can choose how to display the error. The parser supplies structured facts. It doesn't print a message or terminate the process itself.
''','struct CsvError {\n    offset: usize,\n    kind: ErrorKind,\n}\n\nlet at = self.offset;\nself.offset += 1;',[0,1,2,5,6],note='Show byte offset label, never character count. Explain field-start UTF-8 error policy honestly.')

scene('21-split-test','07 · Preserve the actual text','Move the cuts. Keep the answer.','A,"b""c",é\r\n','all_cuts','''
source | Now test the promise we've been making. This small record has an escaped quote, a multibyte character, and a two-byte line ending.
whole | Feed the entire byte sequence to one decoder. Save the delivered record and any error. That's our reference result.
cuts | Then cut after the first byte. Feed the two pieces to a fresh decoder. Compare the result with the reference.
sweep | Move the cut one byte at a time through the whole source, including between quotes, inside é, and between carriage return and line feed.
one_byte | Finally, feed one byte per chunk. There is still only one call to finish, after all the chunks have arrived.
errors | Do the same with malformed inputs. The error kind and source offset must stay the same too. Delivery boundaries shouldn't change the diagnosis.
checkpoint | This is a useful test pattern beyond C S V: vary how input is delivered while keeping its content fixed. The logical result should remain stable.
''','for cut in 0..=input.len() {\n    let mut decoder = Decoder::new();\n    feed(&mut decoder, &input[..cut])?;\n    feed(&mut decoder, &input[cut..])?;\n    finish_and_compare(decoder, expected);\n}',[0,2,3,4],note='Use actual byte cuts in trace; reveal checkmarks only for verified comparisons. Explain pseudocode helper labels.')

scene('22-next-record','08 · One record at a time','The application asks for one record.','Mira,tea\nNoah,milk\n','consumer','''
source | The decoder understands bytes. But an application usually wants a complete record: the next shopper, with all that shopper's fields together.
request | Let the application ask for the next record. The reader consumes input until the decoder produces one, then hands that record over.
deliver | Mira and tea are ready. Return them now. The application can process that shopper before we've parsed every shopper in the file.
retain | Some input may already be buffered after Mira's line. Keep those unread bytes. Asking for one record doesn't mean the operating system supplied exactly one record.
next | On the next request, resume at the first unread byte. Noah and milk become the next record, using the same decoder instance.
memory | This avoids collecting the entire file inside the reader. It still needs an input buffer and space for the record currently being built.
limit | A single enormous quoted record can still be enormous in memory. Streaming means incremental delivery here; it doesn't make the size of a record disappear.
''','for result in Records::new(input) {\n    let record = result?;\n    process(record);\n}',[0,1,2],note='Show one consumer request, one row handoff, retained suffix. Do not animate the source as record-aligned chunks.')

scene('23-input-buffer','08 · One record at a time','A read fills space, not a CSV record.','Mira,tea\nNoah,milk\n','buffer','''
source | What does a read actually give us? We provide a byte buffer. The input source reports how many positions it filled this time.
short | That count can be smaller than the buffer's capacity. Only the filled prefix is valid input; the unused positions must not be scanned.
positions | Keep two indexes: pos, the next unread position, and len, the end of the filled prefix. Advance pos after taking one byte.
record | A record can finish before pos reaches len. Return the record and keep both indexes, so the remaining input stays available.
refill | When pos equals len, the filled prefix is exhausted. Read again, reset pos to zero, and set len to the new byte count.
zero | In this blocking reader, a successful read of zero bytes means final end of input. That's when we call the decoder's finish method.
boundary | The I O layer decides which bytes are available. The decoder decides where records end. Neither layer should pretend those boundaries are the same.
''','if self.pos == self.len {\n    let n = self.input.read(&mut self.buffer)?;\n    self.pos = 0;\n    self.len = n;\n}\nlet byte = self.buffer[self.pos];\nself.pos += 1;',[0,1,2,3,5,6],note='Show buffer capacity and filled prefix separately. This focused excerpt omits zero/error branches, which are introduced next.')

scene('24-iterator','08 · One record at a time','Record, error, or finished.','Mira,tea\n','iterator','''
source | Rust's Iterator interface matches the way the application is asking: give me the next item, or tell me there are no more items.
item | Our item is itself a Result. A successful item holds one record. A failed item holds an error encountered while trying to get that record.
some | So Some of Ok means here's a record. Some of Err means here's a failure. None means the iteration is finished.
unfinished | That None has a different job from the decoder's successful None. The decoder means this byte hasn't completed a record yet. The iterator must keep working.
loop | Its loop reads or takes another buffered byte, feeds the decoder, and repeats until a record, an error, or final completion is available.
code | The associated Item type describes what each successful call to next can yield. The next method borrows the reader mutably because it advances that reader.
variation | An empty input gives None immediately after final completion. A blank line gives Some of Ok containing one empty field, then eventually None.
''','impl<R: Read> Iterator for Records<R> {\n    type Item = Result<Record, ReadError>;\n\n    fn next(&mut self) -> Option<Self::Item> {\n        // Read until a record, error, or final end.\n    }\n}',[0,1,3],note='Resolve the two None meanings explicitly with input/output arrows at distinct interfaces, not just nested type text.')

scene('25-adapter-execute','08 · One record at a time','Follow one request through the loop.','Mira,tea\nNoah,milk','adapter_execute','''
request | Let's execute one next call. The buffer starts empty, so the reader fills it. The filled prefix happens to contain Mira's whole line and part of Noah's.
consume | Take M, then i, r, and a. Each push succeeds without producing a record. The next loop keeps going.
comma | The comma finishes Mira's field, but the record is incomplete. Still no item to return. Tea fills the second field.
newline | The line feed finishes tea and the record. Push now returns a ready record. Next immediately returns that record to the application.
retain | Notice where pos stopped: at Noah's first unread byte. The buffer and its indexes remain inside the reader after the function returns.
resume | A later next call resumes there. If that prefix runs out mid-field, the loop reads another chunk while the decoder preserves the partial field.
generalize | That's the composition: the outer loop waits for a useful result, while the inner decoder handles one byte at a time. Each has a small, explicit job.
''','match self.decoder.push(byte) {\n    Ok(Some(row)) => return Some(Ok(row)),\n    Ok(None) => {},\n    Err(e) => {\n        self.done = true;\n        return Some(Err(ReadError::Csv(e)));\n    }\n}',[0,2,1,4,5],note='Use a program-counter highlight synced to request/consume/return, with the exact retained buffer suffix visible.')

scene('26-final-and-io','08 · One record at a time','Finish once. Report errors once.','Mira,tea','adapter_finish','''
source | What if the last record has no line ending? The loop consumes tea, but it still hasn't received a complete record from push.
zero | The next read returns zero. Now call finish. The decoder completes the last field and gives us the final record.
done | Mark the iterator done before returning it. A later call to next returns None immediately. It doesn't call finish a second time.
error | A syntax error follows the same stopping rule: return the error once, then stop. Earlier records already delivered to the application remain valid.
io | Reading can fail too. An interrupted read is retried. Other read failures become I O errors, distinguished from malformed C S V.
code | The wrapper enum keeps those two error sources separate. Formatting an error produces readable text; the stored error still carries its original structured information.
boundary | The reader never invents an empty record to represent a failure. Data, failure, and final completion each have their own return shape.
''','Ok(0) => {\n    self.done = true;\n    match self.decoder.finish() {\n        Ok(Some(row)) => Some(Ok(row)),\n        Ok(None) => None,\n        Err(e) => Some(Err(ReadError::Csv(e))),\n    }\n}',[0,1,2,3,4,5],note='Show real final branch, not transpose shorthand. Error conversion must preserve source, not erase it.')

scene('27-source-boundary','09 · Put meaning at the right boundary','Change the input source, keep the CSV rules.','Mira,"bread, milk"','io_boundary','''
source | We've used a byte slice so the examples stay small. Replace it with an opened file, and the C S V decisions should stay exactly the same.
read | The reader asks for the Read capability: something that can fill a byte buffer. It doesn't need to know how that source stores its bytes.
generic | In Records of R, R is the chosen source type. The bound R colon Read tells Rust which operation this reader needs from that type.
swap | Our tests supply tiny reads on purpose. The same adapter runs against a file or the test source, and the decoder still sees one byte at a time.
abstraction | This abstraction pays for itself here: we can change delivery and test failures without changing quotation rules or field building.
scope | It is a blocking adapter. A nonblocking source that temporarily has no data needs a different waiting interface; we don't pretend its temporary state is final end.
checkpoint | The complete source checkpoint includes initialization, error formatting, and the finished loop. The active path we've just followed is the same path in that code.
''','pub struct Records<R> {\n    input: R,\n    decoder: Decoder,\n    buffer: [u8; 4096],\n    pos: usize,\n    len: usize,\n    done: bool,\n}',[1,2,3,4,5,6],note='Show byte slice and file connecting to same input buffer; scope limitation belongs here because it affects interface meaning.')

scene('28-schema','09 · Put meaning at the right boundary','A field is text. Its meaning belongs to the app.','name,quantity\nMira,12','schema','''
source | Suppose these records have a name and a quantity. The parser returns the text one two, which the application still needs to interpret as a quantity.
header | Is the first row a header? The C S V core doesn't guess. The application can take the first record as names because its own contract says so.
width | Does every later row need exactly two fields? That's another application rule. Our core can recognize a record even when its field count differs.
convert | The application checks the field count, then converts the quantity string to an integer. A negative quantity might parse as an integer but still violate this application's rules.
errors | Those failures are not quote errors. Keep format errors, number conversion errors, and domain rule failures distinguishable so callers can respond correctly.
boundary | The parser's output is the boundary: complete text fields grouped into records. Application code builds meaning from those values after the format is understood.
variation | Change the second column to a shopping note. The C S V reader stays the same. Only the application's interpretation changes.
''','let record = result?;\nif record.len() != 2 { /* schema error */ }\nlet quantity: u32 = record[1].parse()?;',[0,1,2],note='Avoid unchecked indexing in runnable app; the diagram code explicitly shows successful width validation before indexing.')

scene('29-combined','10 · Put it together','Predict the finished table.','A,"""café"",\nnext",\r\nB,,done','combined','''
source | Time for a fresh example. The first record starts with A. Its note contains quotation marks, an accented character, a comma, and a line break.
predict | Before we run it, look at the quotes and separators. How many fields will the first record have? Take a moment; we'll show the complete answer.
first | The comma after A finishes field one. An opening quote begins the note. The next two quotes contribute one quote to its contents.
middle | Café follows, including the two-byte é. Another doubled quote adds a closing quote inside the note. The comma and line break still belong to that note.
last | Next completes the note's second line. The closing quote leaves quoted contents, and the comma finishes that field. There's now a final empty field.
record | Carriage return plus line feed finishes the first record with three fields. B, an empty middle field, and done form the next three-field record.
resolve | Compare the table with the source. Every content character has a destination. Format quotes and separators did their jobs without becoming extra field contents.
''',note='Fresh combined case must be fully executed and answered. Multi-line output stays inside one cell. Prediction is optional, not a prerequisite.')

scene('30-combined-stream','10 · Put it together','Now move only the delivery boundaries.','A,"""café"",\nnext",\r\nB,,done','combined_stream','''
source | Keep that exact input and exact expected table. Now split the delivery between a quote pair, inside é, and between carriage return and line feed.
quote | At the split quote, retain Quote Seen. When the next quote arrives, append one quote and resume quoted contents.
utf8 | At the split character, retain the raw field bytes. Completing the byte sequence later lets the field convert to the same text.
crlf | At the split line ending, retain the pending line-feed flag and the completed fields. Deliver the record when line feed arrives.
compare | The finished table is unchanged. What crossed each pause was the small amount of context needed to finish the current decision.
cut | Move the cuts again, or feed one byte at a time. Our tests check that the delivered records and any error position remain identical.
generalize | When input delivery changes, keep logical boundaries under the parser's control. Remember unresolved work, rather than letting the transport decide what a value means.
''',note='Use exact same trace case with verified split positions; do not cut between displayed letters while claiming it cuts within UTF-8.')

scene('31-generalize','10 · Put it together','Reuse the principle, not the CSV rules.','length | message bytes','transfer','''
source | Where else does this way of thinking help? Imagine a message stream that gives a length first, followed by that many message bytes.
cut | A read could stop halfway through the length or halfway through the message. Again, the read boundary is not the message boundary.
remember | That parser would remember an unfinished length or how many message bytes remain. It wouldn't need C S V's quoted and bare field states.
compare | The reusable idea is to identify what makes a result complete, then retain the context needed to reach that point across incomplete deliveries.
design | Give each component a small job with a clear handoff. The source supplies bytes, the format parser supplies values, and the application gives those values meaning.
test | Then test the boundary by changing delivery without changing content. It's a direct way to catch assumptions that were accidentally hidden in the first happy-path example.
scope | Different formats have different completion rules. Reuse the method of finding and preserving those rules, not a state machine copied from the wrong problem.
''',note='Message framing visual is a contrast with explicit length boundary. Never imply CSV transition rules transfer directly.')

scene('32-finish','10 · Put it together','A comma gets its meaning from context.','Mira,"bread, milk"','closing','''
source | Return to Mira's shopping note one last time. We started with three broken pieces. Now the same input becomes the two intended fields.
path | We built that result from small decisions: keep content, finish a field, finish a record, and change how punctuation is interpreted when quoting requires it.
state | The difficult moments told us what to remember. Quote Seen preserves an unresolved quote. Field bytes preserve unfinished text. The record keeps fields that belong together.
delivery | The reader carries that work across reads and hands over one completed record at a time. Its buffer boundary never pretends to be a C S V boundary.
resources | The linked source includes the runnable checkpoints, complete reader, format policy, and boundary tests. The transcript and chapters let you return to a specific decision.
next | To extend this reader, begin with a small input and the result you want. Trace the new decision, then add only the state needed to make it correctly.
end | That's the finished path from text to useful records. The comma didn't change. We learned to keep the context that tells us what it means.
''',note='End on successful import and a concrete method for extension, not a generic list of abstractions.')

def write():
    (ROOT/'script.json').write_text(json.dumps(SCENES,indent=2),encoding='utf-8')
    words=sum(len(p['text'].split()) for s in SCENES for p in s['parts'])
    print(f'{len(SCENES)} scenes, {words} words, {sum(len(s["parts"]) for s in SCENES)} spoken turns')

if __name__=='__main__':write()
