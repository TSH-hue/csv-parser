import full from './full-project?project';
import {Renderer,Vector2} from '@motion-canvas/core';
import timeline from '../film-timeline.json';
const index=Number(new URLSearchParams(location.search).get('scene')||0);
const scene=timeline.scenes[index];
const project={...full,scenes:[full.scenes[index]]};
const renderer=new Renderer(project);document.body.append(renderer.stage.finalBuffer);
project.logger.onLogged.subscribe(entry=>console.log('MC',JSON.stringify(entry)));
// Motion Canvas rounds seconds upward to frame indexes. Keep floating-point
// error from turning the inclusive last frame N-1 into an extra frame N.
const lastFrame=(Math.round(scene.duration*30)-1-1e-6)/30;
const settings={...project.meta.getFullRenderingSettings(),name:scene.id,size:new Vector2(1920,1080),resolutionScale:1,fps:30,range:[0,lastFrame] as [number,number],exporter:{name:'@motion-canvas/ffmpeg',options:{includeAudio:false,fastStart:true}}};
(window as any).mc={project,renderer,settings,scene,frame:async(time:number)=>renderer.renderFrame(settings,time),render:async()=>renderer.render(settings)};
renderer.onFinished.subscribe(result=>{(window as any).result=result;console.log('RENDER_RESULT',result)});
renderer.onFrameChanged.subscribe(frame=>{if(frame%900===0)console.log('FRAME',frame)});
(window as any).ready=true;
