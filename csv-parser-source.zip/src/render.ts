import project from './project?project';
import {Renderer, Vector2} from '@motion-canvas/core';

const renderer=new Renderer(project);
document.body.append(renderer.stage.finalBuffer);
project.logger.onLogged.subscribe(entry=>console.log('MC',JSON.stringify(entry)));
const settings={...project.meta.getFullRenderingSettings(),name:'prototype-voiced',size:new Vector2(1920,1080),resolutionScale:1,fps:30,range:[0,100] as [number,number],exporter:{name:'@motion-canvas/ffmpeg',options:{includeAudio:true,fastStart:true}}};
(window as any).mc={project,renderer,settings,
  frame:async(time:number)=>{await renderer.renderFrame(settings,time);},
  render:async()=>{await renderer.render(settings);},
};
renderer.onFinished.subscribe(result=>{(window as any).result=result;console.log('RENDER_RESULT',result)});
renderer.onFrameChanged.subscribe(frame=>{if(frame%300===0)console.log('FRAME',frame)});
(window as any).ready=true;
