import {makeProject} from '@motion-canvas/core';
import prototype from './scenes/prototype?scene';
export default makeProject({scenes:[prototype],audio:'/prototype-script-narration.wav'});
