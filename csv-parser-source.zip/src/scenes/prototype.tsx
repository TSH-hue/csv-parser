import {makeScene2D, Rect, Txt, Line, Node, Code, lines} from '@motion-canvas/2d';
import {all, waitFor, easeInOutCubic, useTime} from '@motion-canvas/core';
import timing from '../../prototype-script-timeline.json';

export default makeScene2D(function*(view){
  view.fill('#100e1c');
  const purple='#be9bff', teal='#6ee7cf', white='#f7f3ff', muted='#9d97ad';
  const text=(s:string,x:number,y:number,size=24,fill=white)=>new Txt({text:s,x,y,fontSize:size,fill,fontFamily:'Segoe UI'});
  view.add(text('ONE QUOTE. TWO POSSIBILITIES.',-607,-450,24,purple));
  const title=text('We have reached a quote.',0,-365,50);view.add(title);
  const source='Noah,"say ""hi"""';
  const sourceNodes:Txt[]=[];
  const sx=-650,sy=-160,step=70;
  const enclosure=new Rect({x:sx+10.5*step,y:sy,width:12*step,height:98,radius:20,fill:'#be9bff08',stroke:purple,lineWidth:2});view.add(enclosure);
  view.add(text('CSV SOURCE',sx+30,-249,22,muted));
  for(let i=0;i<source.length;i++){
    const t=new Txt({text:source[i],x:sx+i*step,y:sy,fontFamily:'Consolas',fontSize:59,fill:white,opacity:i>=11?.08:1});
    sourceNodes.push(t);view.add(t);
  }
  const cutX=sx+10.5*step;
  const cut=new Line({points:[[cutX,-231],[cutX,-90]],stroke:teal,lineWidth:4,lineDash:[8,8],opacity:0});view.add(cut);
  const chunkLabel=text('CHUNK ENDS HERE',cutX,-47,21,teal);chunkLabel.opacity(0);view.add(chunkLabel);
  const fieldCell=new Rect({x:-275,y:137,width:570,height:118,radius:16,fill:'#211b31',stroke:purple,lineWidth:3});view.add(fieldCell);
  view.add(<Rect x={-710} y={137} width={250} height={118} fill="#1b282d" radius={16} stroke="#45605e" lineWidth={2}><Txt text="Noah" fill={white} fontFamily="Consolas" fontSize={44}/></Rect>);
  const field=new Txt({x:-515,y:137,offset:[-1,0],text:'say ',fontFamily:'Consolas',fontSize:44,fill:white});view.add(field);
  const fieldLabel=text('UNFINISHED FIELD',-275,231,22,purple);view.add(fieldLabel);
  const decision=text('QuoteSeen — waiting for one byte',-330,313,24,teal);decision.opacity(0);view.add(decision);
  const focus=new Rect({x:sx+10*step,y:sy,width:58,height:80,radius:10,lineWidth:3,stroke:teal});view.add(focus);
  const alternatives=new Node({x:500,y:130});view.add(alternatives);
  const qa=text('"   →   keep one quote',0,-35,30,teal);qa.opacity(0);alternatives.add(qa);
  const ca=text(',   →   finish this field',0,45,30,purple);ca.opacity(0);alternatives.add(ca);
  const codeNode=new Node({x:475,y:170,opacity:0,scale:.3});view.add(codeNode);
  codeNode.add(<Rect width={765} height={296} radius={16} fill="#191526" stroke="#675477" lineWidth={1}/>);
  const code=new Code({fontFamily:'Consolas',fontSize:24,fill:white,code:'State::QuoteSeen if byte == b\'"\' => {\n    self.field.push(b\'"\');\n    self.state = State::Quoted;\n}'});codeNode.add(code);
  const codeLabel=text('Decoder::push  ·  the doubled-quote branch',0,-114,21,purple);codeNode.add(codeLabel);
  const clip=timing.scenes[0];
  for(const cue of clip.cues){
    yield* waitFor(Math.max(0,cue.start-useTime()));
    switch(cue.action){
      case 'establish':yield* fieldCell.stroke(teal,.4);break;
      case 'quote':yield* all(focus.lineWidth(5,.35),fieldCell.stroke(purple,.35));break;
      case 'cut':yield* all(cut.opacity(1,.5),chunkLabel.opacity(1,.5),title.text('The next byte has not arrived.',.4));break;
      case 'candidate_quote':yield* qa.opacity(1,.45);break;
      case 'candidate_comma':yield* ca.opacity(1,.45);break;
      case 'remember':yield* all(decision.opacity(1,.5),fieldLabel.text('KEEP THE FIELD + THE PENDING DECISION',.4));break;
      case 'arrive':
        yield* all(...sourceNodes.slice(11).map(t=>t.opacity(1,.6)),chunkLabel.text('NEXT CHUNK ARRIVES',.35),cut.opacity(.28,.6),ca.opacity(.15,.4));
        yield* focus.x(sx+11*step,.55,easeInOutCubic);break;
      case 'merge':{
        yield* title.text('Two source quotes → one content quote',.35);
        const left=sourceNodes[10].clone(),right=sourceNodes[11].clone();view.add(left);view.add(right);
        yield* all(sourceNodes[10].opacity(.22,.25),sourceNodes[11].opacity(.22,.25),focus.opacity(0,.25),left.x(cutX,.5),right.x(cutX,.5));right.remove();
        yield* all(left.position([-418,137],1.1,easeInOutCubic),left.fontSize(44,1.1),left.fill(teal,.6));
        field.text('say "');left.remove();yield* fieldCell.stroke(teal,.4);break;
      }
      case 'continue':yield* all(title.text('Keep reading inside the same field.',.4),decision.text('Quoted — reading field contents',.5),alternatives.opacity(0,.4),fieldLabel.text('STILL THE SAME UNFINISHED FIELD',.4));break;
      case 'code_condition':yield* all(codeNode.opacity(1,.5),codeNode.scale(1,.7,easeInOutCubic));yield* code.selection(lines(0),.4);break;
      case 'code_push':yield* code.selection(lines(1),.4);yield* waitFor(1.1);yield* code.selection(lines(2),.4);break;
      case 'recut':yield* all(codeNode.opacity(.25,.4),cut.opacity(1,.4),cut.x(-4*step,1.2),chunkLabel.x(cutX-4*step,1.2),chunkLabel.text('DIFFERENT CUT · SAME CONTENTS',.5),title.text('Input chunks do not define CSV fields.',.5));break;
    }
  }
  yield* waitFor(Math.max(0,clip.duration-useTime()));
});
