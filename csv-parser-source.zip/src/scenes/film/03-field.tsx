import {makeScene2D} from '@motion-canvas/2d';
import {runFilmScene} from '../../film';
export default makeScene2D(function*(view){yield* runFilmScene(view,2);});
