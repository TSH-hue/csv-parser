import {Node,Rect,Txt,Line,View2D} from '@motion-canvas/2d';
import {all,waitFor,useTime,easeInOutCubic,Vector2} from '@motion-canvas/core';
import timeline from '../film-timeline.json';
import traceData from '../film-traces.json';
import {SceneView,C,label,mono,contentText} from './visual';

const traces:any=Object.fromEntries(traceData.map(t=>[t.id,t]));
const utf8=new TextEncoder();
const byteAt=(s:string,char:number)=>utf8.encode(s.slice(0,char)).length;
const length=(s:string)=>utf8.encode(s).length;

class Execution {
  cursor=0;finished=false;pending:any=null;trace:any;budgetEnd=Infinity;
  constructor(public stage:SceneView,id:string){this.trace=traces[id];}
  *replace(id:string){this.trace=traces[id];this.cursor=0;this.finished=false;this.pending=null;yield* this.stage.replace(this.trace.source);}
  *reset(){
    this.cursor=0;this.finished=false;this.pending=null;
    yield* this.stage.table.reset();
    const r=this.stage.ribbon;r.glyphs.forEach(n=>n.opacity(1));
    r.cut.opacity(0);r.cutLabel.opacity(0);r.cutLabel.text('CHUNK ENDS HERE');
    r.focus.opacity(0);r.focus.stroke(C.teal);r.contour.opacity(0);
    this.stage.footer.text('');
  }
  *run(until:number,pace=.12,deliver=true){
    const {ribbon,table}=this.stage;
    const events=this.trace.events.filter((e:any)=>e.event==='byte'&&e.at>=this.cursor&&e.at<until);
    pace=Math.min(pace,Math.max(.015,(this.budgetEnd-useTime()-1.7)/Math.max(events.length*5,1)));
    for(const e of events){
      yield* ribbon.point(e.at,pace);
      const appended=e.field.length>e.field_before.length;
      if(appended&&pace>=.1){
        const idx=ribbon.byteToGlyph[e.at];const original=ribbon.glyphs[idx];
        const copy=original.clone();this.stage.view.add(copy);copy.position(ribbon.pos(e.at).add(ribbon.root.position()));
        const newText=contentText(e.field);const last=newText.split('\n').at(-1)||'';
        const target=table.root.position().add(table.current.position()).add([Math.min(130,(last.length-1)*11),newText.includes('\n')?25:0]);
        if(e.before==='QuoteSeen'&&e.byte===34){
          const prev=ribbon.glyphs[ribbon.byteToGlyph[e.at-1]].clone();this.stage.view.add(prev);prev.position(ribbon.pos(e.at-1).add(ribbon.root.position()));
          yield* all(prev.x(copy.x(),.2),original.opacity(.25,.2),ribbon.glyphs[ribbon.byteToGlyph[e.at-1]].opacity(.25,.2));prev.remove();
        }
        if(e.byte<128){yield* all(copy.position(target,Math.max(.22,pace*2),easeInOutCubic),copy.fontSize(39,.22),copy.fill(C.teal,.22));}
        copy.remove();
      }
      if(e.error){yield* this.error(e.error);this.cursor=e.at+1;return;}
      if(e.delivered){
        if(deliver){yield* table.handoff(e.delivered,.4);yield* table.set([],'',.15);table.caption.text('READY FOR THE NEXT RECORD');}
        else{this.pending=e.delivered;yield* table.set(e.delivered.slice(0,-1),e.delivered.at(-1),.3);}
      }else {yield* table.set(e.row,contentText(e.field),Math.min(.12,pace));table.caption.text('UNFINISHED FIELD');}
      if(parseInt(this.stage.scene.id)>=13)table.state.text(e.awaiting_lf?'Waiting for LF':e.after==='QuoteSeen'?'QuoteSeen · awaiting the next byte':e.after);
      if(e.after==='Quoted'){
        const source=this.trace.source,open=source.indexOf('"');
        if(open>=0)yield* ribbon.quote(byteAt(source,open),Math.max(byteAt(source,source.lastIndexOf('"')),e.at),.08);
      }
      this.cursor=e.at+1;
    }
  }
  *deliver(){if(this.pending){yield* this.stage.table.handoff(this.pending);this.pending=null;yield* this.stage.table.set([],'',.2);this.stage.table.caption.text('READY FOR THE NEXT RECORD');}}
  *eof(){
    if(this.finished)return;
    yield* this.run(length(this.trace.source),.07);
    const e=this.trace.events.find((x:any)=>x.event==='eof');this.finished=true;
    if(!e)return;
    yield* this.stage.ribbon.chunk(length(this.trace.source),false,.2);
    yield* this.stage.ribbon.cutLabel.text('FINAL EOF · no more bytes',.2);
    if(e.error)yield* this.error(e.error);
    else if(e.delivered){yield* this.stage.table.handoff(e.delivered);yield* this.stage.table.set([],'',.2);this.stage.table.caption.text('NO UNFINISHED RECORD');}
    else yield* this.stage.note('FINAL EOF · no additional record');
    if(!e.error){this.stage.table.state.text('Input finished');this.stage.table.caption.text('NO UNFINISHED RECORD');}
  }
  *result(){yield* this.stage.table.result(this.trace.rows);}
  *error(e:any){
    yield* this.stage.ribbon.focus.stroke(C.red,.2);
    this.stage.table.current.stroke(C.red);
    this.stage.table.caption.text('MALFORMED RECORD · not delivered');
    this.stage.table.state.text(parseInt(this.stage.scene.id)>=13?'Decoder closed after error':'Current record rejected');
    yield* this.stage.note(`${e.kind} · byte ${e.at}`);
  }
}

type Plan={to?:number,pace?:number,eof?:boolean,result?:boolean,variant?:string,reset?:boolean,cut?:number,point?:number,arrive?:boolean,code?:number,codeKey?:string,note?:string,hold?:boolean,deliver?:boolean};
function* apply(x:Execution,p:Plan){
  if(p.variant)yield* x.replace(p.variant);
  if(p.reset)yield* x.reset();
  if(p.codeKey){yield* x.stage.code.swap(p.codeKey,p.code||0);if(x.stage.code.root.opacity()<.5)yield* x.stage.code.show(x.stage.table,p.code||0);}
  else if(p.code!==undefined&&x.stage.scene.code){
    if(x.stage.code.root.opacity()<.5)yield* x.stage.code.show(x.stage.table,p.code);
    else yield* x.stage.code.select(p.code);
  }
  if(p.cut!==undefined)yield* x.stage.ribbon.chunk(p.cut);
  if(p.point!==undefined)yield* x.stage.ribbon.point(p.point,.4);
  if(p.arrive)yield* x.stage.ribbon.arrive();
  if(p.to!==undefined)yield* x.run(p.to,p.pace??.1,p.deliver!==false);
  if(p.deliver===true)yield* x.deliver();
  if(p.eof)yield* x.eof();
  if(p.result)yield* x.result();
  if(p.note)yield* x.stage.note(p.note);
}

function simplePlan(s:any,a:string,x:Execution):Plan|undefined{
 const src=s.source,n=length(src),endQuote=byteAt(src,src.lastIndexOf('"')),lf=src.indexOf('\n'),cr=src.indexOf('\r');
 const P:Record<string,Record<string,Plan>>={
  field:{source:{note:'One input · one field'},empty:{reset:true},consume:{to:n,pace:.38},code:{code:0},loop:{reset:true,to:n,pace:.27,code:1},eof:{eof:true,result:true},variation:{variant:'noah',to:4,pace:.27,eof:true,result:true}},
  plain:{source:{reset:true},consume:{to:4,pace:.22},finish_field:{to:5,pace:.6},code:{code:2},take:{code:0,note:'take: move the old vector out · leave an empty vector'},append:{code:1,to:n,pace:.2},eof:{eof:true,result:true}},
  records:{source:{reset:true},consume:{to:lf,pace:.1},finish_field:{to:lf+1,deliver:false,pace:.3},deliver:{deliver:true},code:{code:2},boundary:{code:0,note:'Recognize the boundary → package the completed value'},variation:{to:n,pace:.08,eof:true,result:true}},
  empty:{source:{variant:'trailing',to:5,pace:.2},empty:{eof:true,result:true},leading:{variant:'leading',to:4,pace:.25,eof:true,result:true},blank:{variant:'blank',to:1,pace:.3,result:true,note:'One blank record → one empty field (∅)'},none:{variant:'empty_file',eof:true,result:true,note:'Zero bytes → zero records'},terminal:{variant:'terminal',to:5,pace:.2,eof:true,result:true},checkpoint:{variant:s.id,to:n,pace:.08,eof:true,result:true,note:'Checkpoint 02 · plain fields and records'}},
  quoted:{source:{to:5,pace:.18},open:{to:6,pace:.4},consume:{to:endQuote,pace:.18},close:{to:endQuote+1,pace:.4},resolve:{eof:true,result:true},code:{code:0},variation:{variant:'unquoted',to:length('Mira,bread, milk'),pace:.09,eof:true,result:true,note:'Without the quotes, both commas separate fields.'}},
  multiline:{source:{to:6,pace:.2},inside:{to:lf+1,pace:.25,note:'This LF is field content'},outside:{to:n,pace:.1,result:true,note:'This LF finishes the record'},code:{code:0},abstraction:{code:1},variation:{reset:true,to:n,pace:.06,result:true},checkpoint:{note:'Checkpoint 03 · punctuation gets its job from context'}},
  quote_rules:{source:{note:'An opening quote is allowed only at field start'},valid:{variant:'valid_quote',to:6,pace:.1},invalid:{variant:'bare_quote',to:length('Mira,tea"time'),pace:.14},error:{note:'QuoteInBareField · the quote cannot rewrite earlier contents'},space:{variant:'space_quote',to:length('Mira, "tea"'),pace:.1},boundary:{code:3},variation:{variant:'empty_quote',to:2,pace:.4,eof:true,result:true}},
  doubled:{source:{to:10,pace:.12},encode:{note:'Inside quotes: "" in the source represents " in the value'},first:{to:11,pace:.4},lookahead:{point:11,note:'NEXT BYTE · available in the same input'},merge:{to:12,pace:.45},repeat:{to:16,pace:.22},close:{to:17,pace:.3,eof:true,result:true}},
  after_quote:{source:{to:5,pace:.18},candidate_quote:{variant:'quote_more',to:11,pace:.14,eof:true,result:true},candidate_comma:{variant:s.id,to:6,pace:.2},candidate_eof:{variant:'quote_end',to:5,pace:.17,eof:true,result:true},invalid:{variant:'quote_invalid',to:6,pace:.2},error:{note:'CharacterAfterQuote · byte 5'},generalize:{variant:s.id,to:5,pace:.08,code:0}},
  lookahead:{source:{to:n,pace:.05,eof:true,result:true},code:{code:0},execute:{reset:true,to:n,pace:.12,eof:true,result:true},cut:{reset:true,to:11,pace:.05,cut:11},missing:{note:'No byte in this chunk ≠ final EOF'},problem:{note:'Keep the unfinished field and the unresolved quote'},checkpoint:{note:'Checkpoint 04 · complete-input lookahead has a delivery assumption'}},
  stream_quote:{source:{to:11,pace:.08},cut:{cut:11,note:'The source pauses; the field stays here'},remember:{note:'Needed context: quote seen inside a quoted field'},name:{code:0},arrive:{arrive:true},merge:{to:12,pace:.45,code:1},generalize:{to:n,pace:.14,eof:true,result:true,cut:7,arrive:true}},
  state_execute:{source:{to:5,pace:.12},open:{to:6,pace:.5,codeKey:'16-open'},contents:{to:endQuote,pace:.14,codeKey:'16-contents',code:4},quote:{to:n,pace:.2,eof:true,codeKey:'16-quote'},code:{codeKey:'16-quote',code:0},fallthrough:{codeKey:'16-separators',code:0},checkpoint:{reset:true,to:n,pace:.07,eof:true,result:true}},
  eof:{source:{to:n,pace:.13},chunk:{cut:n,note:'Chunk end: keep waiting'},final:{eof:true},error:{code:0},valid:{variant:'valid_quote',to:10,pace:.1,eof:true,result:true},bare:{variant:'bare_final',to:8,pace:.1,eof:true,result:true},generalize:{note:'push(byte): more content · finish(): no more bytes will ever arrive'}},
  crlf:{source:{to:cr,pace:.1},cr:{to:cr+1,pace:.4},cut:{cut:cr+1,note:'A pending CR waits for LF'},lf:{arrive:true,to:cr+2,pace:.5},code:{code:0},invalid:{variant:'bad_cr',to:10,pace:.1},inside:{variant:'quoted_cr',to:13,pace:.12,eof:true,result:true,note:'Inside quotes, preserve both CR and LF as contents'}},
  errors:{source:{to:n-1,pace:.12},position:{to:n,pace:.4,codeKey:'20-offset',note:`Source byte ${n-1} · indexes start at zero`},kind:{codeKey:'20-errors',code:0},utf8:{note:'InvalidUtf8 is anchored at the source field’s start'},question:{codeKey:'20-propagate',code:1},stop:{codeKey:'20-close',code:1,note:'Error or final completion → closed decoder'},boundary:{codeKey:'20-errors',code:4,note:'The parser returns facts; the application chooses the presentation'}},
  consumer:{source:{reset:true},request:{to:lf+1,pace:.12,deliver:false},deliver:{deliver:true},retain:{point:lf+1,note:'Unread buffered bytes remain available · pos = 9'},next:{to:n,pace:.1,eof:true},memory:{code:0,note:'Input buffer + current field + current record'},limit:{note:'One very large record can still require substantial memory'}},
  adapter_execute:{request:{note:'next() asks for one complete record'},consume:{to:4,pace:.38,code:2},comma:{to:8,pace:.24},newline:{to:9,pace:.5,code:1},retain:{point:9,note:'pos = 9 · the first unread byte is N'},resume:{to:n,pace:.12,eof:true},generalize:{code:0,note:'Outer loop: obtain a record · inner decoder: process one byte'}},
  adapter_finish:{source:{to:n,pace:.17},zero:{eof:true,code:2},done:{code:1,note:'done = true · later next() → None'},error:{note:'A syntax error is yielded once; previously delivered rows stay valid'},io:{note:'Interrupted → retry · other I/O error → yield error and stop'},code:{code:5},boundary:{note:'Record, error, and final end have distinct return shapes'}},
  closing:{source:{to:n,pace:.12,eof:true,result:true},path:{note:'Content → field → record'},state:{note:'Keep only the context needed for the next decision'},delivery:{cut:8,arrive:true},resources:{note:'Source · runnable checkpoints · format policy · tests · transcript'},next:{note:'New input → expected result → new decision → required state'},end:{note:'When a comma is not a separator'}}
 };
 return P[s.mode]?.[a];
}

function* special(x:Execution,a:string,index:number){
 const st=x.stage,s=st.scene,r=st.ribbon,t=st.table,src=s.source,n=length(src);
 if(s.mode==='opening'){
   if(a==='source'||a==='table'){
     yield* t.result([['Mira','bread, milk']]);yield* st.note(a==='source'?'THE INTENDED IMPORT':'Field = cell value · record = related fields in one row');
   }else if(a==='split'||a==='wrong'){
     if(a==='split'){
       t.delivered.removeChildren();const pieces=['Mira','"bread',' milk"'];
       for(let i=0;i<3;i++){
         const cue=s.cues[index],fractions=[.53,.68,.82],names=['one','two','three'];
         const found=cue.words?.find((w:any)=>w.text.toLowerCase().replace(/[^a-z]/g,'')===names[i]);
         const when=found?found.start:cue.start+(cue.spoken_end-cue.start)*fractions[i];
         yield* waitFor(Math.max(0,when-useTime()));
         const ends=[[0,3],[5,10],[12,17]][i];const origin=(r.pos(ends[0]).x+r.pos(ends[1]).x)/2;
         const group=new Node({x:origin,y:-214});const cell=new Rect({width:180,height:120,radius:14,stroke:C.red,lineWidth:2,fill:'#ff909f08',opacity:0});const p=mono(pieces[i],0,0,r.size);group.add(cell);group.add(p);st.extra.add(group);
         yield* all(group.position([-490+i*490,130],.65,easeInOutCubic),p.fontSize(46,.65),cell.width(440,.65),cell.opacity(1,.65));
       }
     }
     yield* st.note('THREE PIECES · the shopping note was cut in half');
   }else if(a==='compare'){
     yield* r.point(4,.3);yield* waitFor(.7);yield* r.point(11,.7);yield* st.note('Same comma · a different job');
   }else if(a==='quotes')yield* r.quote(5,n-1);
   else if(a==='resolve'){
     yield* all(...st.extra.children().map(node=>node.opacity(0,.3)));yield* t.reset();yield* x.run(n,.14);yield* x.eof();yield* x.result();
   }
   return;
 }
 if(s.mode==='roadmap'){
   if(a==='source')yield* t.result([['Mira','bread, milk']]);
   if(a==='grow'){
     const names=['FIELDS','QUOTES','CHUNKS','RECORDS'];
     for(let i=0;i<names.length;i++){const h=label(names[i],-585+i*390,355,26,C.purple);h.opacity(0);st.extra.add(h);yield* h.opacity(1,.25);}
   }
   if(a==='cut')yield* r.chunk(10,false);
   yield* st.note(({checkpoint:'Optional pause-and-code checkpoints · continuous viewing also works',contract:'UTF-8 · quoted fields · LF or CRLF · explicit errors',start:'Start small: one field',code:'Visual decision → small Rust change → execution'} as any)[a]||'Build a CSV reader one working agreement at a time');
   return;
 }
 if(s.mode==='state_build'){
   const snapshots:any={start:['',[], 'Start'],bare:['a',[], 'Bare'],quoted:['b',['a'],'Quoted'],quote_seen:['b',['a'],'QuoteSeen']};
   if(snapshots[a]){
     const [f,row,state]=snapshots[a];yield* t.set(row,f,.5);yield* t.state.text(state,.3);
     const at=({start:0,bare:0,quoted:3,quote_seen:4} as any)[a];yield* r.point(at);
     if(a==='quoted')yield* r.quote(2,4);
   }else if(a==='enum')yield* st.code.show(t,1);
   else if(a==='reason'){yield* st.code.select(4);yield* st.note('Each state preserves a distinction that changes the next legal action');}
   else if(a==='variation'){yield* t.set([],'',.3);yield* t.state.text('Start ≠ Quoted, even when the current text is empty',.3);}
   return;
 }
 if(s.mode==='decoder'){
   if(a==='source')yield* x.run(n,.12);
   else if(a==='group'){
     const bracket=new Rect({x:0,y:166,width:1500,height:300,radius:20,stroke:C.purple,lineWidth:2,fill:'#bd9af704'});st.extra.add(bracket);
     const name=label('Decoder · retains unfinished work',0,349,25,C.purple);st.extra.add(name);yield* bracket.opacity(1,.4);
   }else if(a==='method'){st.extra.removeChildren();yield* st.code.show(t,0);yield* st.code.swap('15-push-signature',0);}
   else if(a==='none'){yield* x.reset();yield* x.run(n-1,.06);yield* st.code.select(3);yield* st.note('Ok(None) · this byte did not complete a record');}
   else if(a==='some'){yield* x.replace('decoder_record');yield* x.run(length(x.trace.source),.06);yield* st.note('Ok(Some(record)) · the LF completed a record');}
   else if(a==='error')yield* st.note('Err(error) · the current record is malformed');
   else yield* st.note('One byte in → update unfinished work → possibly one record out');
   return;
 }
 if(s.mode==='utf8'){
   if(a==='source'){yield* x.run(n-2,.13);yield* st.note('Preserve the accented character');}
   else if(a==='bytes'){
     yield* t.compactMode();yield* r.point(n-1);const z=new Node({x:500,y:90});st.extra.add(z);
     z.add(new Rect({width:440,height:180,radius:18,stroke:C.purple,lineWidth:2,fill:C.panel}));z.add(mono('C3',-92,-20,55));z.add(mono('A9',92,-20,55));z.add(label('two UTF-8 bytes → é',0,52,23,C.teal));z.add(new Line({points:[[0,-72],[0,17]],stroke:C.teal,lineWidth:3,lineDash:[6,6],opacity:0}));yield* z.scale(1.05,.4);
   }else if(a==='cut'){const z=st.extra.children()[0];yield* all(z.children()[2].opacity(.15,.3),z.children()[4].opacity(1,.3));yield* st.note('CHUNK ENDS BETWEEN C3 AND A9 · the first byte waits');}
   else if(a==='keep'){yield* t.set(['Zoë'],'63 61 66 C3',.4);t.caption.text('RAW FIELD BYTES');yield* t.state.text('Incomplete UTF-8 sequence · retain the bytes',.3);}
   else if(a==='decode'){const z=st.extra.children()[0];yield* all(z.children()[2].opacity(1,.4),z.children()[4].opacity(.2,.4));yield* t.set(['Zoë'],'café',.5);t.caption.text('COMPLETE FIELD');t.state.text('Complete UTF-8 · validated String');yield* st.note('Complete field bytes → validated String');}
   else if(a==='syntax'){st.extra.removeChildren();yield* st.code.show(t,0);yield* st.note('ASCII punctuation bytes cannot be UTF-8 continuation bytes');}
   else {yield* st.code.select(3);yield* x.result();}
   return;
 }
 if(s.mode==='all_cuts'||s.mode==='combined_stream'){
   if(a==='source'||a==='whole'){yield* x.result();yield* st.note('REFERENCE RESULT · exact same source bytes');return;}
   const choices=s.mode==='all_cuts'?{cuts:1,sweep:6,one_byte:10,errors:2}: {quote:4,utf8:9,crlf:n-8,compare:1,cut:12};
   const cut=(choices as any)[a];
   if(cut!==undefined){
     st.extra.removeChildren();
     if(a==='utf8'){
       r.cut.opacity(0);r.cutLabel.opacity(0);
       const z=new Rect({x:0,y:-65,width:450,height:115,radius:14,stroke:C.teal,lineWidth:2,fill:C.panel});z.add(mono('C3  |  A9',0,-10,37));z.add(label('chunk boundary inside é',0,33,20,C.teal));st.extra.add(z);
     }else yield* r.chunk(cut,false);
     yield* st.note(a==='errors'?'Malformed inputs must keep the same error kind and byte offset':'Delivery changed · the records stayed identical');
   }
   if(a==='one_byte'||a==='cut'||a==='sweep')for(let i=1;i<n;i+=Math.max(1,Math.floor(n/10)))yield* r.chunk(i,false,.16);
   if(a==='checkpoint'||a==='generalize')yield* st.note('A read boundary is not a logical value boundary');
   return;
 }
 if(s.mode==='buffer'){
   if(a==='source'){
     t.root.opacity(0);const cells=new Node({y:115});st.extra.add(cells);
     for(let i=0;i<20;i++){const q=new Rect({x:-760+i*80,width:73,height:95,radius:8,fill:i<14?'#233a33':'#171420',stroke:i<14?C.teal:C.line,lineWidth:2});q.add(mono(i<14?(src[i]==='\n'?'LF':src[i]||''):'',0,0,30));cells.add(q);}
   }
   const messages:any={source:'4096-byte buffer · showing 20 positions · this read filled 14',short:'Only indexes 0 through len − 1 contain new input',positions:'pos: next unread byte · len: end of the filled prefix',record:'A record finished while pos < len · keep the unread suffix',refill:'pos == len → read again · pos = 0 · len = returned count',zero:'A successful zero-byte read → final EOF in this blocking adapter',boundary:'I/O supplies available bytes · CSV decides record boundaries'};
   yield* st.note(messages[a]);
   if(a==='positions'){
     const stage=st as any;stage.posMarker=new Line({points:[[-760,40],[-760,190]],stroke:C.purple,lineWidth:4});stage.posLabel=label('pos = 0',-760,218,24,C.purple);
     const end=new Line({points:[[320,40],[320,190]],stroke:C.teal,lineWidth:4});
     st.extra.add(stage.posMarker);st.extra.add(stage.posLabel);st.extra.add(end);st.extra.add(label('len = 14',320,218,24,C.teal));
   }
   if(a==='record'){const stage=st as any;yield* all(stage.posMarker.x(720,.8),stage.posLabel.x(-40,.8),stage.posLabel.text('pos = 9',.4));}
   if(a==='refill'){
     yield* all(...st.extra.children().map(v=>v.opacity(0,.3)));st.extra.removeChildren();
     const prefix=new Node({x:-490,y:120});
     ['m','i','l','k','LF'].forEach((value,i)=>{const cell=new Rect({x:-260+i*130,width:116,height:110,radius:10,stroke:C.teal,lineWidth:2,fill:C.panel});cell.add(mono(value,0,0,value==='LF'?25:42));prefix.add(cell);});
     prefix.add(label('NEW FILLED PREFIX',0,-92,23,C.teal));prefix.add(label('pos = 0 · len = 5',0,98,25,C.purple));st.extra.add(prefix);
     yield* st.code.show(t,0);
   }
   return;
 }
 if(s.mode==='iterator'){
   if(a==='source')yield* x.result();
   const labels:any={item:'Iterator item = Result<Record, ReadError>',some:'Some(Ok(record))     Some(Err(error))     None',unfinished:'Decoder: Ok(None) = keep reading     Iterator: None = finished',loop:'Repeat until a record, error, or final completion is available',variation:'Empty file → None     Blank line → Some(Ok([""]))'};
   if(labels[a])yield* st.note(labels[a]);
   if(a==='some'){
     yield* t.root.opacity(0,.3);
     const shapes=[['RECORD','Mira   tea',C.teal],['ERROR','kind + location',C.red],['END','no more items',C.purple]];
     for(let i=0;i<3;i++){
       const cue=s.cues[index],terms=['ok','err','none'];const found=cue.words?.find((w:any)=>w.text.toLowerCase().replace(/[^a-z]/g,'')===terms[i]);
       yield* waitFor(Math.max(0,(found?found.start:cue.start+(cue.spoken_end-cue.start)*[.05,.4,.72][i])-useTime()));
       const q=new Rect({x:-540+i*540,y:150,width:490,height:145,radius:16,fill:C.panel,stroke:shapes[i][2],lineWidth:2,opacity:0});q.add(label(shapes[i][0],0,-32,25,shapes[i][2]));q.add(mono(shapes[i][1],0,27,29));st.extra.add(q);yield* q.opacity(1,.3);
     }
   }
   if(a==='code'){st.extra.removeChildren();t.root.opacity(1);yield* st.code.show(t,3);}
   return;
 }
 if(s.mode==='io_boundary'){
   if(a==='source'){yield* x.result();yield* st.note('The same bytes can come from a byte slice or a file');}
   else if(a==='read'){
     for(let i=0;i<2;i++){const f=new Rect({x:-500+i*1000,y:100,width:440,height:160,radius:12,stroke:i?C.teal:C.purple,lineWidth:2,fill:C.panel});f.add(label(i?'File':'&[u8]',0,0,42));st.extra.add(f);}
   }else if(a==='generic'){st.extra.removeChildren();yield* st.code.show(t,1);yield* st.note('R: Read · any source with the required read operation');}
   else yield* st.note(({swap:'Change delivery without changing the decoder',abstraction:'Test short reads and failures through the same input interface',scope:'Blocking Read adapter · temporary unavailability is not modeled as EOF',checkpoint:'Checkpoint 06 · complete reader, initialization, and error formatting'} as any)[a]||'');
   return;
 }
 if(s.mode==='schema'){
   if(a==='source'||a==='header')yield* x.result();
   const messages:any={source:'CSV fields are strings',header:'The application chooses whether the first record is a header',width:'Validate two fields before indexing',convert:'"12" → integer 12 → application rules',errors:'CSV syntax error ≠ number error ≠ domain rule failure',boundary:'Complete text fields cross the parser boundary',variation:'Change quantity to note · keep the same CSV reader'};
   yield* st.note(messages[a]);
   if(a==='convert')yield* st.code.show(t,2);
   return;
 }
 if(s.mode==='combined'){
   const endFirst=src.indexOf('\r')+2;
   const map:any={source:0,predict:0,first:5,middle:15,last:endFirst-2,record:n,resolve:n};
   if(a==='predict')yield* st.note('Pause if you want to predict · the answer follows');
   else {yield* x.run(Math.min(n,map[a]),.12);if(a==='record'||a==='resolve'){yield* x.eof();yield* x.result();}}
   return;
 }
 if(s.mode==='transfer'){
   if(a==='source'){yield* st.replace('05HELLO03TEA');t.root.opacity(0);yield* st.note('Length 05 → the next five bytes form the message');}
   else if(a==='cut'){yield* st.ribbon.chunk(4);}
   else if(a==='remember'){
     const q=label('2 message bytes received · 3 still needed',0,150,42,C.teal);st.extra.add(q);
   }else yield* st.note(({compare:'Completion comes from the format’s rules',design:'Source → bytes · parser → values · application → meaning',test:'Change delivery; hold content fixed',scope:'Reuse the method · derive the states for each new format'} as any)[a]||'');
   return;
 }
 throw new Error(`Unplanned action: ${s.id} ${a}`);
}

export function* runFilmScene(view:View2D,index:number){
 const scene:any=timeline.scenes[index];const st=new SceneView(view,scene);const x=new Execution(st,scene.id);
 const audit:any[]=[];const global=globalThis as any;global.__audit??={};global.__audit[scene.id]=audit;
 for(let i=0;i<scene.cues.length;i++){
   const cue=scene.cues[i];yield* waitFor(Math.max(0,cue.start-useTime()));x.budgetEnd=cue.end-.1;const began=useTime();
   const p=simplePlan(scene,cue.action,x);
   if(p)yield* apply(x,p);else yield* special(x,cue.action,i);
   audit.push({action:cue.action,plannedStart:cue.start,actualStart:began,actualEnd:useTime(),deadline:cue.end});
 }
 yield* waitFor(Math.max(0,scene.duration-useTime()));
}
