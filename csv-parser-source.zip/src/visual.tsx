import {Code, lines, Node, Rect, Txt, Line, View2D,LezerHighlighter} from '@motion-canvas/2d';
import {parser} from '@lezer/rust';
import {HighlightStyle} from '@codemirror/language';
import {tags} from '@lezer/highlight';
import codeCatalog from '../code-catalog.json';
import {all, easeInOutCubic, sequence, Vector2, waitFor, ThreadGenerator} from '@motion-canvas/core';

export const C={bg:'#100e1c',white:'#f7f3ff',purple:'#bd9af7',teal:'#69dfc9',muted:'#a7a0b7',red:'#ff909f',panel:'#1d172b',line:'#59476d'};
Code.defaultHighlighter=new LezerHighlighter(parser,HighlightStyle.define([
  {tag:tags.keyword,color:C.purple},{tag:tags.string,color:C.teal},
  {tag:tags.comment,color:'#90889f'},{tag:tags.number,color:'#f0c48c'},
  {tag:tags.typeName,color:'#d3b7ff'},{tag:tags.function(tags.variableName),color:'#96dfd0'},
]));
export const label=(text:string,x:number,y:number,size=25,fill=C.white)=>new Txt({text,x,y,fontSize:size,fill,fontFamily:'Segoe UI'});
export const mono=(text:string,x:number,y:number,size=38,fill=C.white)=>new Txt({text,x,y,fontSize:size,fill,fontFamily:'Consolas'});
export const contentText=(bytes:number[])=>new TextDecoder('utf-8').decode(new Uint8Array(bytes),{stream:true});

export class Ribbon {
  root=new Node({}); glyphs:Txt[]=[]; positions:Vector2[]=[]; byteToGlyph:number[]=[];
  focus=new Rect({width:47,height:76,radius:9,stroke:C.teal,lineWidth:3,opacity:0});
  contour=new Rect({height:91,radius:17,stroke:C.purple,lineWidth:2,fill:'#bd9af708',opacity:0});
  cut=new Line({points:[[0,-62],[0,66]],stroke:C.teal,lineWidth:3,lineDash:[7,8],opacity:0});
  cutLabel=label('CHUNK ENDS HERE',0,-107,21,C.teal);
  source:string; size:number; step:number; left:number;
  constructor(view:View2D,source:string){
    this.source=source;const chars=Array.from(source);
    this.size=Math.min(64,1500/Math.max(chars.length,1)/.69);this.step=this.size*.66;this.left=-(chars.length-1)*this.step/2;
    this.root.y(-214);view.add(this.root);this.root.add(this.contour);
    let byte=0;
    chars.forEach((ch,i)=>{
      const shown=ch==='\n'?'LF':ch==='\r'?'CR':ch;
      const t=mono(shown,this.left+i*this.step,0,ch==='\n'||ch==='\r'?this.size*.38:this.size);
      if(ch==='\n'||ch==='\r')t.fill(C.purple);
      this.glyphs.push(t);this.positions.push(new Vector2(t.x(),0));this.root.add(t);
      for(let n=0;n<new TextEncoder().encode(ch).length;n++)this.byteToGlyph[byte++]=i;
    });
    this.root.add(this.focus);this.root.add(this.cut);this.cutLabel.opacity(0);this.root.add(this.cutLabel);
  }
  pos(byte:number){return this.positions[this.byteToGlyph[Math.min(byte,this.byteToGlyph.length-1)]]||new Vector2(0,0);}
  *point(byte:number,d=.28){yield* all(this.focus.position(this.pos(byte),d,easeInOutCubic),this.focus.opacity(1,d));}
  *quote(start:number,end:number,d=.4){
    const a=this.pos(start).x,b=this.pos(end).x;
    yield* all(this.contour.x((a+b)/2,d),this.contour.width(b-a+this.step*1.15,d),this.contour.opacity(1,d));
  }
  *chunk(at:number,hidden=true,d=.5){
    const g=this.byteToGlyph[at]??this.glyphs.length;const x=this.left+(g-.5)*this.step;
    yield* all(this.cut.x(x,d),this.cut.opacity(1,d),this.cutLabel.x(x,d),this.cutLabel.text('CHUNK ENDS HERE',d),this.cutLabel.opacity(1,d),...this.glyphs.map((t,i)=>t.opacity(hidden&&i>=g?.12:1,d)));
  }
  *arrive(d=.5){yield* all(...this.glyphs.map(t=>t.opacity(1,d)),this.cut.opacity(.25,d),this.cutLabel.text('NEXT CHUNK ARRIVES',d));}
}

export class Table {
  root=new Node({y:100}); working=new Node({}); delivered=new Node({y:215});
  cells:Rect[]=[]; texts:Txt[]=[]; current:Rect; currentText:Txt;
  caption=label('UNFINISHED FIELD',0,107,21,C.purple);
  state=label('',0,158,24,C.teal);compact=false; maxWidth=1450;
  receipt=label('COMPLETED RECORD',0,190,20,C.teal);
  rowValues:string[]=[];fieldValue='';resultRows:string[][]|null=null;lastRecord:string[]|null=null;
  constructor(view:View2D){
    view.add(this.root);this.root.add(this.working);this.root.add(this.delivered);
    this.current=new Rect({width:520,height:124,radius:14,stroke:C.purple,lineWidth:2,fill:'#221b32'});
    this.currentText=mono('',0,0,42);this.current.add(this.currentText);
    this.working.add(this.current);this.root.add(this.caption);this.root.add(this.state);this.receipt.opacity(0);this.root.add(this.receipt);
  }
  *set(row:string[],field:string,animate=.3){
    this.rowValues=[...row];this.fieldValue=field;this.resultRows=null;
    const total=row.length+1;const width=this.compact?760:Math.min(1480,total*350+120);const cellWidth=width/total;
    const origin=-(width-cellWidth)/2;
    while(this.cells.length>row.length){this.cells.pop()!.remove();this.texts.pop();}
    for(let i=this.cells.length;i<row.length;i++){
      const r=new Rect({width:cellWidth-12,height:124,radius:14,stroke:'#53665e',lineWidth:2,fill:'#1a292a',opacity:0});const t=mono('',0,0,37);r.add(t);this.working.add(r);this.cells.push(r);this.texts.push(t);
    }
    const tasks:any[]=[];
    for(let i=0;i<row.length;i++){
      const val=row[i];this.texts[i].text(val||'∅');this.texts[i].fill(val?C.white:C.muted);
      this.texts[i].fontSize(Math.min(39,(cellWidth-35)/Math.max(...val.split('\n').map(s=>s.length),1)/.57));
      tasks.push(this.cells[i].x(origin+i*cellWidth,animate),this.cells[i].width(cellWidth-12,animate),this.cells[i].opacity(1,animate));
    }
    this.currentText.text(field);this.currentText.fontSize(Math.min(42,(cellWidth-36)/Math.max(...field.split('\n').map(s=>s.length),1)/.57));
    const height=field.includes('\n')?160:124;
    tasks.push(this.current.x(origin+row.length*cellWidth,animate),this.current.width(cellWidth-12,animate),this.current.height(height,animate),this.caption.x(origin+row.length*cellWidth,animate));
    yield* all(...tasks);
  }
  *handoff(row:string[],d=.6){
    this.lastRecord=[...row];
    this.receipt.opacity(1);
    const group=new Node({y:0});const total=row.length,w=this.compact?740:1400,cw=w/Math.max(total,1);
    row.forEach((v,i)=>{
      const r=new Rect({x:-(w-cw)/2+i*cw,width:cw-12,height:110,radius:14,fill:'#18302d',stroke:C.teal,lineWidth:2});
      const t=mono(v||'∅',0,0,Math.min(38,(cw-30)/Math.max(...v.split('\n').map(x=>x.length),1)/.57),v?C.white:C.muted);r.add(t);group.add(r);
    });this.root.add(group);
    yield* all(group.y(255,d,easeInOutCubic),group.scale(.86,d),this.working.opacity(.3,d));
    this.delivered.removeChildren();group.reparent(this.delivered);group.y(40);
    yield* this.working.opacity(1,.25);
  }
  *result(rows:string[][],d=.5){
    this.resultRows=rows.map(row=>[...row]);
    this.receipt.opacity(0);
    this.working.opacity(0);this.caption.opacity(0);this.state.opacity(0);this.delivered.removeChildren();
    const count=Math.max(...rows.map(x=>x.length),1),w=this.compact?760:1450,cw=w/count;
    rows.forEach((row,r)=>row.forEach((v,i)=>{
      const cell=new Rect({x:-(w-cw)/2+i*cw,y:r*150-210,width:cw-12,height:v.includes('\n')?138:116,radius:14,stroke:C.teal,lineWidth:2,fill:'#1b2c2b',opacity:0});
      cell.add(mono(v||'∅',0,0,Math.min(44,(cw-40)/Math.max(...v.split('\n').map(x=>x.length),1)/.57),v?C.white:C.muted));this.delivered.add(cell);
    }));yield* all(...this.delivered.children().map(n=>n.opacity(1,d)));
  }
  *reset(){this.delivered.removeChildren();this.receipt.opacity(0);this.working.opacity(1);this.caption.opacity(1);this.caption.text('UNFINISHED FIELD');this.state.opacity(1);this.state.text('');this.current.stroke(C.purple);yield* this.set([],'',.2);}
  *compactMode(){
    if(this.compact)return;
    this.compact=true;
    const rows=this.resultRows;
    const tasks:any[]=[this.root.x(-490,.7,easeInOutCubic),rows?this.result(rows,.4):this.set(this.rowValues,this.fieldValue,.7)];
    if(!rows&&this.lastRecord&&this.delivered.children().length){
      const group=this.delivered.children()[0],cw=740/this.lastRecord.length;
      group.children().forEach((node,i)=>{const rect=node as Rect;const text=rect.children()[0] as Txt;const value=this.lastRecord![i];tasks.push(rect.width(cw-12,.7),rect.x(-(740-cw)/2+i*cw,.7),text.fontSize(Math.min(38,(cw-30)/Math.max(...value.split('\n').map(v=>v.length),1)/.57),.7));});
    }
    yield* all(...tasks);
  }
}

export class CodeView {
  root=new Node({x:480,y:120,opacity:0,scale:.18});code:Code;title:Txt;overview=new Node({x:480,y:100,opacity:0});overviewCode:Code;selectionRect:Rect;meta:any;opened=false;panel:Rect;
  constructor(view:View2D,source:string,id:string){
    this.meta=(codeCatalog as any)[id];if(this.meta)source=this.meta.code;
    view.add(this.overview);
    this.overview.add(new Rect({width:840,height:575,radius:14,fill:C.panel,stroke:C.line,lineWidth:1}));
    const allLines=(this.meta?.full||source).split('\n');
    const start=Math.max(0,(this.meta?.start||0)-9),end=Math.min(allLines.length,start+36);
    const overviewText=allLines.slice(start,end).join('\n');
    this.overviewCode=new Code({code:overviewText,fontFamily:'Consolas',fontSize:Math.min(14,480/Math.max(end-start,1)),fill:C.white});this.overview.add(this.overviewCode);
    this.overview.add(label(this.meta?.path||'Rust source',0,-265,23,C.purple));
    const lineHeight=this.overviewCode.fontSize()*1.2;
    const top=-(end-start)*lineHeight/2;
    this.selectionRect=new Rect({x:0,y:top+((this.meta?.start||0)-start+Math.min(this.meta?.end-this.meta?.start||4,10)/2)*lineHeight,width:750,height:Math.min(this.meta?.end-this.meta?.start||4,10)*lineHeight+12,radius:8,stroke:C.teal,lineWidth:2,fill:'#69dfc90b'});this.overview.add(this.selectionRect);
    view.add(this.root);
    const lineCount=source.split('\n').length;
    this.panel=new Rect({width:875,height:Math.max(270,Math.min(530,lineCount*40+100)),radius:15,fill:C.panel,stroke:C.line,lineWidth:1});this.root.add(this.panel);
    const max=Math.max(...source.split('\n').map(x=>x.length),1);
    this.code=new Code({code:source,fontFamily:'Consolas',fontSize:Math.min(29,795/max/.61),fill:C.white,drawHooks:{token(ctx,text,position,color,selection){ctx.globalAlpha*=.5+selection*.5;ctx.fillStyle=color;ctx.fillText(text,position.x,position.y);}}});
    this.title=label(this.meta?`${this.meta.path} · lines ${this.meta.start+1}–${this.meta.end}`:'RUST · CURRENT CHANGE',0,-Math.max(95,Math.min(240,lineCount*20+20)),20,C.purple);
    this.root.add(this.code);this.root.add(this.title);
  }
  *show(table:Table,line=0){
    yield* table.compactMode();
    if(!this.opened){
      yield* this.overview.opacity(1,.35);yield* waitFor(.45);
      this.root.position([480,100+this.selectionRect.y()]);this.root.scale(.32);
      yield* all(this.root.opacity(1,.35),this.root.position([480,120],.65,easeInOutCubic),this.root.scale(1,.65,easeInOutCubic),this.overview.opacity(0,.5));this.opened=true;
    }else yield* this.root.opacity(1,.3);
    yield* this.select(line);
  }
  *select(line:number){yield* this.code.selection(lines(Math.min(line,this.code.parsed().split('\n').length-1)),.25);}
  *swap(id:string,line=0){
    const meta=(codeCatalog as any)[id];if(!meta)return;
    this.meta=meta;
    if(!this.opened){
      const sourceLines=meta.full.split('\n'),start=Math.max(0,meta.start-9),end=Math.min(sourceLines.length,start+36),height=Math.min(14,480/Math.max(end-start,1))*1.2;
      this.overviewCode.code(sourceLines.slice(start,end).join('\n'));this.overviewCode.fontSize(height/1.2);
      this.selectionRect.y(-(end-start)*height/2+(meta.start-start+Math.min(meta.end-meta.start,10)/2)*height);this.selectionRect.height(Math.min(meta.end-meta.start,10)*height+12);
    }
    const count=meta.code.split('\n').length,max=Math.max(...meta.code.split('\n').map((s:string)=>s.length),1);
    yield* all(this.code.code(meta.code,.45),this.code.fontSize(Math.min(29,795/max/.61),.4),this.panel.height(Math.max(270,Math.min(530,count*40+100)),.4),this.title.y(-Math.max(95,Math.min(240,count*20+20)),.4),this.title.text(`${meta.path} · lines ${meta.start+1}–${meta.end}`,.4));
    yield* this.select(line);
  }
  *hide(){yield* this.root.opacity(0,.4);}
}

export class SceneView {
  ribbon:Ribbon;table:Table;code:CodeView;title:Txt;sub:Txt;extra=new Node({});footer:Txt;
  constructor(public view:View2D,public scene:any){
    view.fill(C.bg);
    const chapter=label(scene.chapter.toUpperCase(),-830,-470,22,C.purple);chapter.offset([-1,0]);view.add(chapter);
    this.title=label(scene.title,0,-383,48);view.add(this.title);
    this.sub=label('',0,-303,24,C.muted);view.add(this.sub);
    this.ribbon=new Ribbon(view,scene.source);this.table=new Table(view);this.code=new CodeView(view,scene.code||'',scene.id);
    if(parseInt(scene.id)>=22)this.table.receipt.text('APPLICATION · DELIVERED RECORD');
    if(scene.id==='03-field')this.table.receipt.text('COMPLETED FIELD');
    this.footer=label('',0,470,22,C.muted);view.add(this.footer);view.add(this.extra);
  }
  *note(s:string){yield* this.footer.text(s,.3);}
  *replace(source:string){this.ribbon.root.remove();this.ribbon=new Ribbon(this.view,source);yield* this.table.reset();yield* this.note('');}
}
